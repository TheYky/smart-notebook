//
//  MainHelper.h
//  BasicFramework
//
//  Created by MAC on 2023/6/12.
//
/*===============================================================================
 
 App的生命周期及推送分享等功能的继承等操作的维护；
 
 ===============================================================================*/

#import <Foundation/Foundation.h>

@interface MainHelper : NSObject


@end
