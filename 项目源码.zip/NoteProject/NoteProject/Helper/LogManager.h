//
//  LogManager.h
//  BasicFramework
//
//  Created by MAC on 2023/6/12.
//
/*===============================================================================
 
 App的crash日志监控、全局容错处理业务等的维护；
 
 ===============================================================================*/

#import <Foundation/Foundation.h>

@interface LogManager : NSObject


@end
