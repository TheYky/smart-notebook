//
//  AppDelegate+UI.h
//  BasicFramework
//
//  Created by MAC on 2023/6/12.
//
/*===============================================================================
 
 AppDelegate的UI方面的维护：启动页、广告页等；
 
 ===============================================================================*/

#import "AppDelegate.h"

@interface AppDelegate (UI)


/**
 *  获取启动页
 *
 *  @return UIImageView
 */
-(UIImageView *)GetPortraitIMG;

#pragma mark 设置rootViewController
-(void)setMyWindowAndRootViewController;

-(void)setMyWindowAndLoginViewController;

@end
