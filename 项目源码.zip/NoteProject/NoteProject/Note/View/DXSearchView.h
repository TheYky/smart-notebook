//
//  DXSearchView.h
//  NoteProject
//
//  Created by MAC on 2023/6/12.
//

#import <UIKit/UIKit.h>

/**
 自定义searchBar 只设置加载在viewController.view上
 */
@interface DXSearchView : UIView
@property (nonatomic,copy) NSString * place_holderText;
@property (nonatomic,copy) void(^editingBlock)(void);
@property (nonatomic,copy) void(^editTextChanged)(NSString * text);

@property (nonatomic,copy) void(^endEditingBlock)(void);
@property (nonatomic,copy) void(^searchResultBlock)(NSString * searchRusult);
@property (nonatomic,assign) BOOL showCancelBtn;
//- (instancetype)initWithEditingBlock:(void(^)(DXSearchView * searchView))editingBlock;
@end
