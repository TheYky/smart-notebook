//
//  DXNoteContCell.m
//  NoteProject
//
//  Created by MAC on 2023/6/13.
//

#import "DXNoteContCell.h"

@interface DXNoteContCell ()

@property (nonatomic, strong) UIView * bgView;

@property (nonatomic, strong) UIImageView *iconImageView;
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UILabel *countLabel;
@property (strong, nonatomic) UILabel * timeLabel;

@end

@implementation DXNoteContCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
        self.contentView.backgroundColor = [UIColor clearColor];
        self.backgroundColor = [UIColor clearColor];
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        
        [self setupUI];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
}

- (void)setupUI {
    
    [self.contentView addSubview:self.bgView];
    [self.bgView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.contentView).offset(KScalHeight(12));
        make.right.equalTo(self.contentView).offset(-KScalHeight(12));
        make.top.equalTo(self.contentView).offset(KScalHeight(12));
        make.bottom.equalTo(self.contentView);
    }];
    
    [self.bgView addSubview:self.iconImageView];
    [self.iconImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.bgView).offset(KScalHeight(12));
        make.top.equalTo(self.bgView).offset(KScalHeight(14));
        make.size.mas_equalTo(CGSizeMake(KScalHeight(14), KScalHeight(14)));
    }];
    
    [self.bgView addSubview:self.titleLabel];
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.bgView).offset(KScalHeight(32));
        make.top.equalTo(self.bgView).offset(KScalHeight(12));
        make.right.equalTo(self.bgView).offset(-KScalHeight(12));
    }];
    
    [self.bgView addSubview:self.countLabel];
    [self.countLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.bgView).offset(KScalHeight(32));
        make.top.equalTo(self.titleLabel.mas_bottom).offset(KScalHeight(12));
        make.right.equalTo(self.bgView).offset(-KScalHeight(12));
    }];
    
    [self.bgView addSubview:self.timeLabel];
    [self.timeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.bgView).offset(KScalHeight(12));
        make.top.equalTo(self.countLabel.mas_bottom).offset(KScalHeight(18));
        make.right.equalTo(self.bgView).offset(-KScalHeight(12));
        make.bottom.equalTo(self.bgView).offset(-KScalHeight(12));
    }];
    
    [self layoutIfNeeded];
    self.bgView.layer.cornerRadius = 6.0;
    [self.bgView.layer setShadowColor:[UIColor blackColor].CGColor];
    [self.bgView.layer setShadowOpacity:0.1];
    [self.bgView.layer setShadowRadius:1.0f];
    [self.bgView.layer setShadowOffset:CGSizeMake(0.0, 0.0)];
}

- (void)setModel:(DXFreContModel *)model {
    
    self.titleLabel.text = model.title;
    self.countLabel.text = model.content;
    self.timeLabel.text = model.dateTime;
}

#pragma mark - 懒加载

- (UIView *)bgView {
    if (!_bgView) {
        _bgView = [[UIView alloc] init];
        _bgView.backgroundColor = [UIColor whiteColor];
    }
    return _bgView;
}

- (UIImageView *)iconImageView {
    
    if (!_iconImageView) {
        _iconImageView = [[UIImageView alloc] init];
        _iconImageView.image = [UIImage imageNamed:@"Note_label_icon"];
    }
    return _iconImageView;
}

- (UILabel *)titleLabel {
    if (!_titleLabel) {
        _titleLabel = [[UILabel alloc] init];
        _titleLabel.font = [UIFont boldSystemFontOfSize:16];
        _titleLabel.text = @"";
        _titleLabel.textColor = [UIColor blackColor];
        _titleLabel.backgroundColor = [UIColor clearColor];
        _titleLabel.numberOfLines = 2;
        _titleLabel.lineBreakMode = NSLineBreakByTruncatingTail;
    }
    return _titleLabel;
}

- (UILabel *)countLabel {
    if (!_countLabel) {
        _countLabel = [[UILabel alloc] init];
        _countLabel.font = [UIFont systemFontOfSize:14];
        _countLabel.text = @"";
        _countLabel.textColor = [[UIColor blackColor] colorWithAlphaComponent:0.6];
        _countLabel.textAlignment = NSTextAlignmentLeft;
        _countLabel.lineBreakMode = NSLineBreakByTruncatingTail;
        _countLabel.numberOfLines = 2;
    }
    return _countLabel;
}

- (UILabel *)timeLabel {
    if (!_timeLabel) {
        _timeLabel = [[UILabel alloc] init];
        _timeLabel.font = [UIFont systemFontOfSize:12];
        _timeLabel.text = @"";
        _timeLabel.textColor = [[UIColor blackColor] colorWithAlphaComponent:0.6];
        _timeLabel.textAlignment = NSTextAlignmentRight;
    }
    return _timeLabel;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end



