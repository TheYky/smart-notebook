//
//  DXSearchPopView.h
//  NoteProject
//
//  Created by MAC on 2023/6/12.
//

#import <UIKit/UIKit.h>
@interface DXSearchPopView : UIView
@property (nonatomic,assign) CGFloat animationTime;
@property (nonatomic, strong) NSArray *dataSource;

/**展示tableView
 @param array dataSource */
- (void)showThePopViewWithArray:(NSMutableArray *)array;
/** *  移除popView */
- (void)dismissThePopView;

- (instancetype)initWithAttributeBlock:(void(^)(DXSearchPopView * popView))attributeBlock;

- (void)reloadTableView;

@end
