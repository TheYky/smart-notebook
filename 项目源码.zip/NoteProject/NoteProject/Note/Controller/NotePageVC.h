//
//  NotePageVC.h
//  NoteProject
//
//  Created by MAC on 2023/6/12.
//

#import "BasicMainVC.h"

NS_ASSUME_NONNULL_BEGIN

@interface NotePageVC : BasicMainVC

@end

NS_ASSUME_NONNULL_END
