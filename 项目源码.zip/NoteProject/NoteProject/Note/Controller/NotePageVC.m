//
//  NotePageVC.m
//  NoteProject
//
//  Created by MAC on 2023/6/12.
//

#import "NotePageVC.h"
#import "NSString+chineseTransform.h"
#import "DXNoteContCell.h"
#import "DXSearchPopView.h"
#import "DXSearchView.h"
#import "SearchCoreManager.h"
#import "NoteWriteVC.h"

#define SCREEN_WIDTH [[UIScreen mainScreen] bounds].size.width
#define SCREEN_HEIGHT [[UIScreen mainScreen] bounds].size.height
#define SCREEN_MAX_LENGTH (MAX(SCREEN_WIDTH, SCREEN_HEIGHT))
#define SCREEN_MIN_LENGTH (MIN(SCREEN_WIDTH, SCREEN_HEIGHT))
#define IS_IPHONE (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
#define IS_IPHONE_X (IS_IPHONE && SCREEN_MAX_LENGTH == 812.0)
#define COLOR_HEX(hexValue) [UIColor colorWithRed:((float)((hexValue & 0xFF0000) >> 16)) / 255.0 green:((float)((hexValue & 0xFF00) >> 8)) / 255.0 blue:((float)(hexValue & 0xFF)) / 255.0 alpha:1.0f]
static CGFloat viewOffset = 64;

@interface NotePageVC ()<UITableViewDataSource,UITableViewDelegate>

@property (nonatomic,weak) DXSearchView * searchBar;
@property (nonatomic,strong) UITableView * tableView;
@property (nonatomic,strong) UIView * navigation_View;
@property (nonatomic,strong) DXSearchPopView * searchPopView;
@property (nonatomic,strong) NSMutableDictionary * dataDict;//搜索数据源
@property (nonatomic,strong) NSArray * dataSource;
@property (nonatomic,strong) NSMutableArray * searchNameResultArry;
@property (nonatomic, strong) UIImageView * bgImageView;

@property (nonatomic, strong) UILabel * titleLabel;
@property (nonatomic, strong) UIButton * backButton;
@property (nonatomic, strong) UIButton * writeButton;
@property (nonatomic, strong) UIButton * sortButton;

@property (nonatomic, strong) UIView * bottomView;
@property (nonatomic, strong) UILabel * countLabel;

//0 不排序 1 按时间正序 2按时间倒序
@property (nonatomic, assign) NSInteger sortType;

@end

@implementation NotePageVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self initData];
    
    [self.view addSubview:self.bgImageView];
    [self.bgImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.bottom.equalTo(self.view);
    }];
    
    [self setupUI];
    self.sortType = 0;
    
    [self setSearchViewTo_dis];
    [self setTableViewTo_dis];
    [self setSearchPopViewTo_dis];
    [self.tableView reloadData];
    
    // Do any additional setup after loading the view.
}

- (void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:animated];

    [self initData];
    
    NSInteger count = [[NotesManager sharedInstance] getBooksCount];
    self.countLabel.text = [NSString stringWithFormat:@"%ld个便签",(long)count];
}

- (void)viewWillDisappear:(BOOL)animated {
    
    [super viewWillDisappear:animated];
}

- (void)setupUI{
    
    [self.view addSubview:self.titleLabel];
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view).offset(kStatusBarHeight);
        make.left.right.equalTo(self.view);
        make.height.mas_equalTo(KScalHeight(44));
    }];
    
    [self.view addSubview:self.backButton];
    [self.backButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view).offset(kStatusBarHeight);
        make.left.equalTo(self.view).offset(KScalHeight(14));
        make.size.mas_equalTo(CGSizeMake(KScalHeight(44), KScalHeight(44)));
    }];
    
    [self.view addSubview:self.sortButton];
    [self.sortButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view).offset(kStatusBarHeight);
        make.right.equalTo(self.view).offset(-KScalHeight(14));
        make.size.mas_equalTo(CGSizeMake(KScalHeight(44), KScalHeight(44)));
    }];
    
    [self.view addSubview:self.bottomView];
    [self.bottomView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.left.right.mas_equalTo(self.view);
        make.height.mas_equalTo(kSafeBottomSpaceBar + KScalHeight(50));
    }];
    
    [self.bottomView addSubview:self.countLabel];
    [self.countLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(self.bottomView);
        make.top.mas_equalTo(self.bottomView).offset(KScalHeight(18));
    }];
    
    [self.bottomView addSubview:self.writeButton];
    [self.writeButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.countLabel);
        make.right.equalTo(self.bottomView).offset(-KScalHeight(14));
        make.size.mas_equalTo(CGSizeMake(KScalHeight(38), KScalHeight(38)));
    }];
}

- (void)backButtonAction:(UIButton *)button{
    
    [self.navigationController popViewControllerAnimated:NO];
}

- (void)writeButtonAction:(UIButton *)button{
    
    NoteWriteVC * vc = [[NoteWriteVC alloc] init];
    vc.isEdit = NO;
    [self.navigationController pushViewController:vc animated:NO];
}

- (void)sortButtonAction:(UIButton *)button{
    
    if(self.sortType == 2) {
        self.sortType = 0;
    } else {
        self.sortType = self.sortType + 1;
    }
    if(self.sortType == 0) {
        [self.sortButton setImage:[UIImage imageNamed:@"Note_sort_defalut_icon"] forState:UIControlStateNormal];
    }
    if(self.sortType == 1) {
        [self.sortButton setImage:[UIImage imageNamed:@"Note_sort_up_icon"] forState:UIControlStateNormal];
    }
    if(self.sortType == 2) {
        [self.sortButton setImage:[UIImage imageNamed:@"Note_sort_down_icon"] forState:UIControlStateNormal];
    }
 
    [self initData];
}


- (void)setSearchPopViewTo_dis{
    self.searchPopView = ({
        DXSearchPopView * popView = [[DXSearchPopView alloc]initWithAttributeBlock:^(DXSearchPopView *popView) {
            popView.animationTime = 0.25;
        }];
        [self.view addSubview:popView];
        [popView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.view.mas_bottom).offset(KScalHeight(33));
            make.left.mas_equalTo(self.view.mas_left);
            make.width.mas_equalTo(self.view.mas_width);
            make.height.mas_equalTo(self.view.bounds.size.height - kNavigationBarHeight);
        }];
        popView;
    });
}

- (void)setSearchViewTo_dis{
    
    DXSearchView * bar = [[DXSearchView alloc]init];
    [self.view addSubview:bar];
    self.searchBar = bar;
    __weak typeof(self)weakSelf = self;
    
    bar.layer.cornerRadius = 6;
    
    bar.editingBlock = ^{
        [UIView animateWithDuration:0.5 animations:^{
            weakSelf.navigationController.navigationBar.transform = CGAffineTransformMakeTranslation(0, -viewOffset);
            weakSelf.searchBar.transform = CGAffineTransformMakeTranslation(0, -viewOffset + 20);
            weakSelf.searchBar.backgroundColor = UIColor.whiteColor;
            weakSelf.searchBar.showCancelBtn = YES;
            weakSelf.navigation_View.backgroundColor = UIColor.whiteColor;
        }];
        [weakSelf.searchPopView showThePopViewWithArray:[NSMutableArray array]];
    };
    
    bar.endEditingBlock = ^{
        [UIView animateWithDuration:0.5 animations:^{
            weakSelf.navigationController.navigationBar.transform = CGAffineTransformIdentity;
            weakSelf.searchBar.transform = CGAffineTransformIdentity;
            weakSelf.searchBar.backgroundColor = UIColor.clearColor;
            weakSelf.searchBar.showCancelBtn = NO;
            weakSelf.navigation_View.backgroundColor = COLOR_HEX(0x467dff);
        }];
        weakSelf.searchPopView.dataSource = @[];
        [weakSelf.searchPopView dismissThePopView];
        weakSelf.searchPopView.dataSource = @[];
    };
    
    bar.searchResultBlock = ^(NSString * searchRusult){

    };
    
    bar.place_holderText = @"搜索";
    [bar mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.and.right.mas_equalTo(0);
        make.height.mas_equalTo(50);
        make.top.mas_equalTo(kNavigationBarHeight);
    }];
    
    bar.editTextChanged = ^(NSString *text) {
        [[SearchCoreManager share] Search:text searchArray:nil nameMatch:weakSelf.searchNameResultArry phoneMatch:nil];
        NSNumber * localID;
        NSMutableString *matchString = [NSMutableString string];//为了在库中找到匹配的号码或者是拼音 有那个显示那个
        NSMutableArray * tmpArry = NSMutableArray.new;
        NSMutableArray *matchPos = [NSMutableArray array];
        for (int i = 0; i < weakSelf.searchNameResultArry.count; i ++) {
            localID = [weakSelf.searchNameResultArry objectAtIndex:i];
            
            if ([text length]) {
                [[SearchCoreManager share] GetPinYin:localID pinYin:matchString matchPos:matchPos];
                DXFreContModel * model = [weakSelf.dataDict objectForKey:localID];
                if(model != nil) {
                    [tmpArry addObject:model];
                }
            }
        }
        weakSelf.searchPopView.dataSource = tmpArry.mutableCopy;
    };
    
}
- (void)setTableViewTo_dis{
    UITableView * tableView = [[UITableView alloc]init];
    self.tableView = tableView;
    tableView.delegate = self;
    tableView.dataSource = self;
    [self.view addSubview:tableView];
    self.tableView = tableView;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    tableView.rowHeight = 55;
    [tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.searchBar.mas_bottom);
        make.left.and.right.mas_equalTo(0);
        make.bottom.mas_equalTo(-kSafeBottomSpaceBar - KScalHeight(50));
    }];
    tableView.backgroundColor = [UIColor clearColor];
    tableView.tableFooterView = UIView.new;
}

- (void)initData{
    
    NSDictionary * noteDict = [[NotesManager sharedInstance] readPlist];
    
    NSMutableArray * tmpArray = NSMutableArray.new;
    NSArray * keys = [noteDict allKeys];
    for (int i = 0; i < keys.count; i ++) {
        NSDictionary * itemDict = noteDict[keys[i]];
        DXFreContModel * model = [[DXFreContModel alloc]initWithUserId:itemDict[@"userID"] DateTime:itemDict[@"dateTime"] title:itemDict[@"title"] content:itemDict[@"content"]];
        model.timeStamp = [self getTimeStampWithString:itemDict[@"dateTime"]];
        [tmpArray addObject:model];
    }
    
    if(self.sortType == 2) {
        [tmpArray sortUsingComparator:^NSComparisonResult(DXFreContModel *obj1, DXFreContModel *obj2) {
            return [@(obj1.timeStamp) compare:@(obj2.timeStamp)];
        }];
    }
    if(self.sortType == 1) {
        [tmpArray sortUsingComparator:^NSComparisonResult(DXFreContModel *obj1, DXFreContModel *obj2) {
            return [@(obj2.timeStamp) compare:@(obj1.timeStamp)];
        }];
    }
    
    _dataSource = tmpArray.mutableCopy;
    
    self.dataDict = [NSMutableDictionary dictionary];
    for (int i = 0; i<self.dataSource.count; i++) {
        DXFreContModel * model = self.dataSource[i];
        [[SearchCoreManager share] AddContact:@(i) name:model.title phone:nil];
        [self.dataDict setObject:model forKey:@(i)];
    }
    
    [self.tableView reloadData];
}

- (long)getTimeStampWithString:(NSString *)formatTime{
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateStyle:NSDateFormatterMediumStyle];
    [formatter setTimeStyle:NSDateFormatterShortStyle];
    [formatter setDateFormat:@"yyyy年MM月dd日 HH:mm:ss"];

    NSTimeZone* timeZone = [NSTimeZone timeZoneWithName:@"Asia/Beijing"];
    [formatter setTimeZone:timeZone];
    NSDate* date = [formatter dateFromString:formatTime];
    NSInteger timeSp = [[NSNumber numberWithDouble:[date timeIntervalSince1970]] integerValue] * 1000;
    
    return (long)timeSp;
}

#pragma mark - UITableViewDataSource & Delegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.dataSource == nil ? 10 : self.dataSource.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    
    return 0.01;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return UITableViewAutomaticDimension;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    DXNoteContCell * cell = [tableView dequeueReusableCellWithIdentifier:@"cellID"];
    if (!cell) {
        cell = [[DXNoteContCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cellID"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    cell.model = (DXFreContModel *)self.dataSource[indexPath.row];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    DXFreContModel * model = (DXFreContModel *)self.dataSource[indexPath.row];
    
    NoteWriteVC * vc = [[NoteWriteVC alloc] init];
    vc.isEdit = YES;
    vc.noteModel = model;
    [self.navigationController pushViewController:vc animated:NO];
}

- (BOOL)tableView:(UITableView*)tableView canEditRowAtIndexPath:(NSIndexPath*)indexPath {

    return YES;
}

- (UITableViewCellEditingStyle)tableView:(UITableView*)tableView editingStyleForRowAtIndexPath:(NSIndexPath*)indexPath {

    return UITableViewCellEditingStyleDelete;
}

- (NSString*)tableView:(UITableView*)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath*)indexPath {
    
    return @"删除";
}

- (void)tableView:(UITableView*)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath*)indexPath {

    DXFreContModel * model = (DXFreContModel *)self.dataSource[indexPath.row];
    [[NotesManager sharedInstance] removeBookWithKey:model.dateTime];
    
    [self initData];
}

- (NSMutableDictionary *)dataDict{
    
    if (!_dataDict) {
        _dataDict = NSMutableDictionary.new;
    }
    return _dataDict;
}

- (NSMutableArray *)searchNameResultArry{
    
    if (!_searchNameResultArry) {
        _searchNameResultArry = [NSMutableArray array];
    }
    return _searchNameResultArry;
}


#pragma mark -- Lazy load

- (UILabel *)titleLabel{
    
    if (!_titleLabel) {
        _titleLabel = [[UILabel alloc] init];
        _titleLabel.font = [UIFont boldSystemFontOfSize:18];
        _titleLabel.textColor = [UIColor whiteColor];
        _titleLabel.numberOfLines = 1;
        _titleLabel.text = @"便签";
        _titleLabel.textAlignment = NSTextAlignmentCenter;
        _titleLabel.lineBreakMode = NSLineBreakByTruncatingTail;
        _titleLabel.backgroundColor = [UIColor clearColor];
    }
    return _titleLabel;
}

- (UIButton *)backButton{
    
    if(!_backButton) {
        _backButton = [[UIButton alloc] init];
        [_backButton setImage:[UIImage imageNamed:@"Back"] forState:UIControlStateNormal];
        [_backButton addTarget:self action:@selector(backButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _backButton;
}

- (UIButton *)writeButton{
    
    if(!_writeButton) {
        _writeButton = [[UIButton alloc] init];
        [_writeButton setImage:[UIImage imageNamed:@"Note_write_icon"] forState:UIControlStateNormal];
        [_writeButton addTarget:self action:@selector(writeButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _writeButton;
}

- (UIButton *)sortButton{
    
    if(!_sortButton) {
        _sortButton = [[UIButton alloc] init];
        [_sortButton setImage:[UIImage imageNamed:@"Note_sort_defalut_icon"] forState:UIControlStateNormal];
        [_sortButton addTarget:self action:@selector(sortButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _sortButton;
}

- (UIView *)bottomView{
    
    if(!_bottomView){
        _bottomView = [[UIView alloc] init];
        _bottomView.backgroundColor = [UIColor whiteColor];
    }
    return _bottomView;
}

- (UILabel *)countLabel{
    
    if (!_countLabel) {
        _countLabel = [[UILabel alloc] init];
        _countLabel.font = [UIFont systemFontOfSize:13];
        _countLabel.textColor = [UIColor blackColor];
        _countLabel.numberOfLines = 1;
        _countLabel.text = @"10个便签";
        _countLabel.textAlignment = NSTextAlignmentCenter;
        _countLabel.lineBreakMode = NSLineBreakByTruncatingTail;
        _countLabel.backgroundColor = [UIColor clearColor];
    }
    return _countLabel;
}

- (UIImageView *)bgImageView{
    
    if (!_bgImageView) {
        _bgImageView = [[UIImageView alloc] init];
        _bgImageView.image = [UIImage imageNamed:@"Home_bg"];
    }
    return _bgImageView;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
