//
//  NoteWriteVC.h
//  NoteProject
//
//  Created by MAC on 2023/6/14.
//

#import "BasicMainVC.h"
#import "DXFreContModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface NoteWriteVC : BasicMainVC

@property (nonatomic, assign) BOOL isEdit;
@property (nonatomic, strong) DXFreContModel * noteModel;

@end

NS_ASSUME_NONNULL_END
