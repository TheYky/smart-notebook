//
//  NoteWriteVC.m
//  NoteProject
//
//  Created by MAC on 2023/6/14.
//

#import "NoteWriteVC.h"

@interface NoteWriteVC ()

@property (nonatomic, strong) UILabel * titleLabel;
@property (nonatomic, strong) UIButton * backButton;
@property (nonatomic, strong) UIButton * writeButton;

@property (nonatomic, strong) ZYFPlaceholderTextView * titleTextView;
@property (nonatomic, strong) ZYFPlaceholderTextView * contentTextView;

@property (nonatomic, strong) UIView * titleView;
@property (nonatomic, strong) UIView * contentView;

@property (nonatomic, strong) NSString * titleString;
@property (nonatomic, strong) NSString * contentString;

@property (nonatomic, strong) UIButton * submitButton;
@property (nonatomic, strong) NotesManager * noteManager;

@property (nonatomic, strong) UIImageView * bgImageView;

@property(nonatomic, strong) UITapGestureRecognizer * tapGesture;

@end

@implementation NoteWriteVC

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    [self.view addSubview:self.bgImageView];
    [self.bgImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.bottom.equalTo(self.view);
    }];
    
    [self.view addGestureRecognizer:self.tapGesture];
    
    [self setupUI];
    
    self.titleLabel.text = self.isEdit == YES ? @"修改便签" : @"新建便签";
    self.writeButton.hidden = self.isEdit == NO ;
    
    self.titleTextView.textView.text = self.noteModel.title;
    self.contentTextView.textView.text =  self.noteModel.content;
    
    self.titleString = self.noteModel.title;
    self.contentString = self.noteModel.content;
    
    if(self.titleString.length > 0) {
        self.titleTextView.placeholder = @"";
    }else {
        self.titleTextView.placeholder = @"请输入便签标题";
    }
    if(self.contentString.length > 0) {
        self.contentTextView.placeholder = @"";
    }else {
        self.contentTextView.placeholder = @"请输入便签内容";
    }
    
    self.noteManager = [NotesManager sharedInstance];
    
    // Do any additional setup after loading the view.
}

- (void)setupUI{
    
    [self.view addSubview:self.titleLabel];
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view).offset(kStatusBarHeight);
        make.left.right.equalTo(self.view);
        make.height.mas_equalTo(KScalHeight(44));
    }];
    
    [self.view addSubview:self.backButton];
    [self.backButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view).offset(kStatusBarHeight);
        make.left.equalTo(self.view).offset(KScalHeight(14));
        make.size.mas_equalTo(CGSizeMake(KScalHeight(44), KScalHeight(44)));
    }];
    
    [self.view addSubview:self.writeButton];
    [self.writeButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view).offset(kStatusBarHeight);
        make.right.equalTo(self.view).offset(-KScalHeight(14));
        make.size.mas_equalTo(CGSizeMake(KScalHeight(44), KScalHeight(44)));
    }];
    
    [self.view addSubview:self.titleView];
    [self.titleView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view).offset(kNavigationBarHeight + KScalHeight(36));
        make.right.equalTo(self.view).offset(-KScalHeight(36));
        make.left.equalTo(self.view).offset(KScalHeight(36));
        make.height.mas_equalTo(KScalHeight(60));
    }];
    
    [self.titleView addSubview:self.titleTextView];
    [self.titleTextView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.equalTo(self.titleView).offset(KScalHeight(12));
        make.bottom.right.equalTo(self.titleView).offset(-KScalHeight(12));
    }];
    
    [self.view addSubview:self.contentView];
    [self.contentView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.titleView.mas_bottom).offset(KScalHeight(36));
        make.right.equalTo(self.view).offset(-KScalHeight(36));
        make.left.equalTo(self.view).offset(KScalHeight(36));
        make.height.mas_equalTo(KScalHeight(300));
    }];
    
    [self.contentView addSubview:self.contentTextView];
    [self.contentTextView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.equalTo(self.contentView).offset(KScalHeight(12));
        make.bottom.right.equalTo(self.contentView).offset(-KScalHeight(12));
    }];
    
    [self.view addSubview:self.submitButton];
    [self.submitButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(CGSizeMake(Device_Width-KScalHeight(56), KScalHeight(50)));
        make.bottom.equalTo(self.view.mas_bottom).offset(-kSafeBottomSpaceBar-KScalHeight(20));
        make.centerX.equalTo(self.view);
    }];
}

- (void)change{
    
    if(self.titleString.length <= 0 || self.contentString.length <= 0) {
        
        [NoteHUD showToastMessage:@"请将便签内容补充完整" toView:self.view];
        return;
    }
    
    [[NotesManager sharedInstance] removeBookWithKey:self.noteModel.dateTime];
    [self sava];
}

- (void)sava{
    
    if(self.titleString.length <= 0 || self.contentString.length <= 0) {
        
        [NoteHUD showToastMessage:@"请将便签内容补充完整" toView:self.view];
        return;
    }
    
    if([[NotesManager sharedInstance] isPlistFileExists] == YES) {

        NSMutableDictionary *addDictionary1 = [[NSMutableDictionary alloc] init];
        
        NSString *title = self.titleString;
        NSString *content = self.contentString;
        NSDate *currentDate = [NSDate date];
        NSDateFormatter*df = [[NSDateFormatter alloc]init];
        [df setDateFormat:@"yyyy年MM月dd日 HH:mm:ss"];
        NSString *dateTime = [df stringFromDate:currentDate];
        NSDictionary * userInfo = [FileCacheManager getValueInMyLocalStoreForKey:Online_User_Info];
        NSString *userID = userInfo[@"userId"];
        
        [addDictionary1 setValue:title forKey:@"title"];
        [addDictionary1 setValue:content forKey:@"content"];
        [addDictionary1 setValue:dateTime forKey:@"dateTime"];
        [addDictionary1 setValue:userID forKey:@"userID"];
        
        [[NotesManager sharedInstance]writePlist:addDictionary1 forKey:dateTime];
        
        [NoteHUD showToastMessage:@"便签保存成功" toView:self.view];
    
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{//主线程
            [self.navigationController popViewControllerAnimated:NO];
        });
    }
}

-(void)viewGestureAction:(UITapGestureRecognizer *)tap{

    CGPoint point = [tap locationInView:self.view];
    point = [self.view.layer convertPoint:point fromLayer:self.view.layer];
    if([self.view.layer containsPoint:point]) {
        [self.titleTextView.textView resignFirstResponder];
        [self.contentTextView.textView resignFirstResponder];
    }
}


- (void)backButtonAction:(UIButton *)button{
    
    [self.navigationController popViewControllerAnimated:NO];
}

- (void)deleteButtonAction:(UIButton *)button{
    
    [[NotesManager sharedInstance] removeBookWithKey:self.noteModel.dateTime];
    [NoteHUD showToastMessage:@"便签删除成功" toView:self.view];

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{//主线程
        [self.navigationController popViewControllerAnimated:NO];
    });
}

- (void)submitButtonClicked:(UIButton *)button{
    
    if(self.isEdit == YES) {
        [self change];
    }else {
        [self sava];
    }
    
}


#pragma mark -- Lazy load

- (UITapGestureRecognizer *)tapGesture {
    
    if(!_tapGesture) {
        _tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(viewGestureAction:)];
    }
    return _tapGesture;
}

- (UILabel *)titleLabel{
    
    if (!_titleLabel) {
        _titleLabel = [[UILabel alloc] init];
        _titleLabel.font = [UIFont boldSystemFontOfSize:18];
        _titleLabel.textColor = [UIColor whiteColor];
        _titleLabel.numberOfLines = 1;
        _titleLabel.text = @"新增便签";
        _titleLabel.textAlignment = NSTextAlignmentCenter;
        _titleLabel.lineBreakMode = NSLineBreakByTruncatingTail;
        _titleLabel.backgroundColor = [UIColor clearColor];
    }
    return _titleLabel;
}

- (UIButton *)backButton{
    
    if(!_backButton) {
        _backButton = [[UIButton alloc] init];
        [_backButton setImage:[UIImage imageNamed:@"Back"] forState:UIControlStateNormal];
        [_backButton addTarget:self action:@selector(backButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _backButton;
}

- (UIButton *)writeButton{
    
    if(!_writeButton) {
        _writeButton = [[UIButton alloc] init];
        [_writeButton setImage:[UIImage imageNamed:@"Note_delete_icon"] forState:UIControlStateNormal];
        [_writeButton addTarget:self action:@selector(deleteButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _writeButton;
}

- (UIView *)titleView {
    
    if(!_titleView){
        _titleView = [[UIView alloc] init];
        _titleView.layer.borderWidth = 1;
        _titleView.layer.borderColor = [[UIColor whiteColor] colorWithAlphaComponent:0.5].CGColor;
        _titleView.layer.cornerRadius = KScalHeight(10);
    }
    return _titleView;
}

- (UIView *)contentView {
    
    if(!_contentView){
        _contentView = [[UIView alloc] init];
        _contentView.layer.borderWidth = 1;
        _contentView.layer.borderColor = [[UIColor whiteColor] colorWithAlphaComponent:0.7].CGColor;
        _contentView.layer.cornerRadius = KScalHeight(10);
    }
    return _contentView;
}

- (ZYFPlaceholderTextView *)titleTextView{
    
    if(!_titleTextView) {
        _titleTextView = [[ZYFPlaceholderTextView alloc] init];
        _titleTextView.maxLength = 20;
        _titleTextView.textView.scrollEnabled = NO;
        _titleTextView.showFootNumber = NO;
        _titleTextView.placeholder = @"";
        _titleTextView.textView.font = [UIFont systemFontOfSize:16];
        _titleTextView.backgroundColor = [UIColor clearColor];
        _titleTextView.placeholderColor = [[UIColor whiteColor] colorWithAlphaComponent:0.5];
        _titleTextView.textView.textColor = [UIColor whiteColor];
        _titleTextView.placeholderFont = [UIFont systemFontOfSize:16];
        WeakSelf;
        [_titleTextView addTextDidChangeHandler:^(NSString *text) {
            NSLog(@"=====%@",text);
            weakSelf.titleTextView.placeholder = @"请输入便签题目";
            weakSelf.titleString = text;
        }];
        [_titleTextView addTextLengthDidMaxHandler:^(NSString *text) {
            NSLog(@"=====MAX");
        }];
    }
    return _titleTextView;
}

- (ZYFPlaceholderTextView *)contentTextView{
    
    if(!_contentTextView) {
        _contentTextView = [[ZYFPlaceholderTextView alloc] init];
        _contentTextView.maxLength = 300;
        _contentTextView.textView.scrollEnabled = NO;
        _contentTextView.showFootNumber = YES;
        _contentTextView.placeholder = @"";
        _contentTextView.backgroundColor = [UIColor clearColor];
        _contentTextView.textView.font = [UIFont systemFontOfSize:16];
        _contentTextView.placeholderFont = [UIFont systemFontOfSize:16];
        _contentTextView.placeholderColor = [[UIColor whiteColor] colorWithAlphaComponent:0.5];
        _contentTextView.textView.textColor = [UIColor whiteColor];
        WeakSelf;
        [_contentTextView addTextDidChangeHandler:^(NSString *text) {
            NSLog(@"=====%@",text);
            weakSelf.contentTextView.placeholder = @"请输入便签内容";
            weakSelf.contentString = text;
        }];
        [_contentTextView addTextLengthDidMaxHandler:^(NSString *text) {
            NSLog(@"=====MAX");
        }];
    }
    return _contentTextView;
}

- (UIButton *)submitButton{
    
    if(!_submitButton) {
        _submitButton = [[UIButton alloc] init];
        [_submitButton setTitle:@"保存" forState:UIControlStateNormal];
        [_submitButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_submitButton setBackgroundColor:[UIColor colorWithHex:@"#64BC80"]];
        [_submitButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        _submitButton.titleLabel.font = [UIFont boldSystemFontOfSize:18];
        [_submitButton addTarget:self action:@selector(submitButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
        _submitButton.layer.masksToBounds = YES;
        _submitButton.layer.cornerRadius = KScalHeight(25);
    }
    return _submitButton;
}

- (UIImageView *)bgImageView{
    
    if (!_bgImageView) {
        _bgImageView = [[UIImageView alloc] init];
        _bgImageView.image = [UIImage imageNamed:@"Home_bg"];
    }
    return _bgImageView;
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
