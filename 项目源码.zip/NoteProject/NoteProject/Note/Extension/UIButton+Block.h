//
//  UIButton+Block.h
//  NoteProject
//
//  Created by MAC on 2023/6/12.
//

#import <UIKit/UIKit.h>

@interface UIButton (Block)
@property(nonatomic,copy)void(^actionBlock)(UIButton *);
-(void)addTargetActionBlock:(void(^)(UIButton *btn))block;
- (void)startWithTime:(NSInteger)timeLine title:(NSString *)title countDownTitle:(NSString *)subTitle mainColor:(UIColor *)mColor countColor:(UIColor *)color;
@end
