//
//  UITextField (RAC)
//  NoteProject
//
//  Created by MAC on 2023/6/12.
//

#import <UIKit/UIKit.h>

@interface UITextField (RAC)
@property(nonatomic,copy)void(^editTextHandler)(NSString *text);
@end
