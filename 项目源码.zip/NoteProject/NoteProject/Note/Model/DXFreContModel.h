//
//  DXFreContModel.h
//  NoteProject
//
//  Created by MAC on 2023/6/12.
//

#import <Foundation/Foundation.h>

/**
 装载常用联系人的模型
 */
@interface DXFreContModel : NSObject

@property (nonatomic,copy) NSString * userID;
@property (nonatomic,copy) NSString * dateTime;
@property (nonatomic,copy) NSString * title;
@property (nonatomic,copy) NSString * content;
@property (nonatomic,assign) long timeStamp;

- (instancetype)initWithUserId:(NSString *)userID DateTime:(NSString *)time title:(NSString *)title content:(NSString *)content;

@end
