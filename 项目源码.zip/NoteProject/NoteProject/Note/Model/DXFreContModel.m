//
//  DXFreContModel.m
//  NoteProject
//
//  Created by MAC on 2023/6/12.
//

#import "DXFreContModel.h"

@implementation DXFreContModel

- (instancetype)initWithUserId:(NSString *)userID DateTime:(NSString *)time title:(NSString *)title content:(NSString *)content{
    if (self == [super init]) {
        self = [super init];
        
        NSDictionary * userInfo = [FileCacheManager getValueInMyLocalStoreForKey:Online_User_Info];
        
        self.userID = userInfo[@"userId"];
        self.title = title;
        self.dateTime = time;
        self.content = content;
    }
    return self;
}

@end
