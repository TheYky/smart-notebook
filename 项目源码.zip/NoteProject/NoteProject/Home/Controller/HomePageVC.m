//
//  HomePageVC.m
//  NoteProject
//
//  Created by MAC on 2023/6/12.
//

#import "HomePageVC.h"
#import "NotePageVC.h"
#import "CMPlayerViewController.h"
#import "CalculatorPageVC.h"
#import "LoginVC.h"


@interface HomePageVC ()

@property (nonatomic, strong) UIImageView * bgImageView;

@property (nonatomic, strong) UIButton * noteButton;
@property (nonatomic, strong) UIButton * calcutorButton;
@property (nonatomic, strong) UIButton * playerButton;

@property (nonatomic, strong) UIButton * logoutButton;

@end

@implementation HomePageVC

- (void)viewDidLoad {
    
    [super viewDidLoad];
 
    [self setupUI];
    [self ceateNotesPlist];
}

- (void)ceateNotesPlist{
    
    NSString *plistPath =[[NotesManager sharedInstance] getPlistPath];
    
    if( [[NotesManager sharedInstance] isPlistFileExists] == NO) {

        NSMutableDictionary *addDictionary1 = [[NSMutableDictionary alloc] init];
        
        NSString *title = [NSString stringWithFormat:@"欢迎使用INote便签"];
        NSString *content = [NSString stringWithFormat:@"希望您使用愉快"];
        NSDate *currentDate = [NSDate date];
        NSDateFormatter*df = [[NSDateFormatter alloc]init];
        [df setDateFormat:@"yyyy年MM月dd日 HH:mm:ss"];
        NSString *dateTime = [df stringFromDate:currentDate];
        NSDictionary * userInfo = [FileCacheManager getValueInMyLocalStoreForKey:Online_User_Info];
        NSString *userID = userInfo[@"userId"];
        
        [addDictionary1 setValue:title forKey:@"title"];
        [addDictionary1 setValue:content forKey:@"content"];
        [addDictionary1 setValue:dateTime forKey:@"dateTime"];
        [addDictionary1 setValue:userID forKey:@"userID"];
        
        [[NotesManager sharedInstance]writePlist:addDictionary1 forKey:dateTime];
    }
}

- (void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:animated];
    
    [self.navigationController setNavigationBarHidden:YES];
}

- (void)viewWillDisappear:(BOOL)animated {
    
    [super viewWillDisappear:animated];
}

- (void)setupUI{
    
    [self.view addSubview:self.bgImageView];
    [self.bgImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.bottom.equalTo(self.view);
    }];
    
    [self.view addSubview:self.calcutorButton];
    [self.view addSubview:self.noteButton];
    [self.view addSubview:self.playerButton];
    [self.view addSubview:self.logoutButton];
    
    [self.calcutorButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.view).offset(-KScalHeight(170));
        make.centerX.equalTo(self.view);
        make.size.mas_equalTo(CGSizeMake(Device_Width-KScalHeight(50), KScalHeight(70)));
    }];
    
    [self.noteButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.calcutorButton.mas_top).offset(-KScalHeight(30));
        make.centerX.equalTo(self.view);
        make.size.mas_equalTo(CGSizeMake(Device_Width-KScalHeight(50), KScalHeight(70)));
    }];
    
    [self.playerButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.calcutorButton.mas_bottom).offset(KScalHeight(30));
        make.centerX.equalTo(self.view);
        make.size.mas_equalTo(CGSizeMake(Device_Width-KScalHeight(50), KScalHeight(70)));
    }];
    
    [self.logoutButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.view).offset(-kNavigationBarHeight-KScalHeight(10));
        make.centerX.equalTo(self.view);
        make.size.mas_equalTo(CGSizeMake(Device_Width-KScalHeight(50), KScalHeight(70)));
    }];
    
    [self.view layoutIfNeeded];
    
    self.calcutorButton.layer.masksToBounds = YES;
    self.calcutorButton.layer.cornerRadius = KScalHeight(15);
    self.calcutorButton.layer.borderWidth = 2.0;
    self.calcutorButton.layer.borderColor = [UIColor whiteColor].CGColor;
    
    self.noteButton.layer.masksToBounds = YES;
    self.noteButton.layer.cornerRadius = KScalHeight(15);
    self.noteButton.layer.borderWidth = 2.0;
    self.noteButton.layer.borderColor = [UIColor whiteColor].CGColor;
    
    self.playerButton.layer.masksToBounds = YES;
    self.playerButton.layer.cornerRadius = KScalHeight(15);
    self.playerButton.layer.borderWidth = 2.0;
    self.playerButton.layer.borderColor = [UIColor whiteColor].CGColor;
    
    self.logoutButton.layer.masksToBounds = YES;
    self.logoutButton.layer.cornerRadius = KScalHeight(15);
    self.logoutButton.layer.borderWidth = 2.0;
    self.logoutButton.layer.borderColor = [[UIColor whiteColor] colorWithAlphaComponent:0.7].CGColor;
    
}

- (void)noteButtonAction:(UIButton *)button{
    
    NotePageVC * vc = [[NotePageVC alloc] init];
    [self.navigationController pushViewController:vc animated:NO];
}

- (void)calcutorButtonAction:(UIButton *)button{
    
    CalculatorPageVC * vc = [[CalculatorPageVC alloc] init];
    [self.navigationController pushViewController:vc animated:NO];
}

- (void)playerButtonAction:(UIButton *)button{
    
    CMPlayerViewController * vc = [[CMPlayerViewController alloc] init];
    [self.navigationController pushViewController:vc animated:NO];
}

- (void)logoutButtonAction:(UIButton *)button {
    
    [FileCacheManager saveInMyLocalStoreForValue:@{} atKey:Online_User_Info];
    [self.navigationController pushViewController:[[LoginVC alloc] init] animated:NO];
}

#pragma mark -- Lazy Load

- (UIImageView *)bgImageView{
    
    if (!_bgImageView) {
        _bgImageView = [[UIImageView alloc] init];
        _bgImageView.image = [UIImage imageNamed:@"Home_bg"];
    }
    return _bgImageView;
}

- (UIButton *)noteButton{
    
    if(!_noteButton) {
        _noteButton = [[UIButton alloc] init];
        [_noteButton setTitle:@"  便签" forState:UIControlStateNormal];
        [_noteButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_noteButton setImage:[UIImage imageNamed:@"Home_note_icon"] forState:UIControlStateNormal];
        [_noteButton setBackgroundColor:[UIColor clearColor]];
        _noteButton.titleLabel.font = [UIFont boldSystemFontOfSize:24];
        [_noteButton addTarget:self action:@selector(noteButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _noteButton;
}

- (UIButton *)calcutorButton{
    
    if(!_calcutorButton) {
        _calcutorButton = [[UIButton alloc] init];
        [_calcutorButton setTitle:@"  计算器" forState:UIControlStateNormal];
        [_calcutorButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_calcutorButton setImage:[UIImage imageNamed:@"Home_calcutor_icon"] forState:UIControlStateNormal];
        [_calcutorButton setBackgroundColor:[UIColor clearColor]];
        _calcutorButton.titleLabel.font = [UIFont boldSystemFontOfSize:24];
        [_calcutorButton addTarget:self action:@selector(calcutorButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _calcutorButton;
}

- (UIButton *)playerButton{
    
    if(!_playerButton) {
        _playerButton = [[UIButton alloc] init];
        [_playerButton setTitle:@"  音乐播放器" forState:UIControlStateNormal];
        [_playerButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_playerButton setImage:[UIImage imageNamed:@"Home_player_icon"] forState:UIControlStateNormal];
        [_playerButton setBackgroundColor:[UIColor clearColor]];
        _playerButton.titleLabel.font = [UIFont boldSystemFontOfSize:24];
        [_playerButton addTarget:self action:@selector(playerButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _playerButton;
}

- (UIButton *)logoutButton{
    
    if(!_logoutButton) {
        _logoutButton = [[UIButton alloc] init];
        [_logoutButton setTitle:@"退出登录" forState:UIControlStateNormal];
        [_logoutButton setTitleColor:[[UIColor whiteColor] colorWithAlphaComponent:0.7] forState:UIControlStateNormal];
        [_logoutButton setBackgroundColor:[UIColor clearColor]];
        _logoutButton.titleLabel.font = [UIFont boldSystemFontOfSize:24];
        [_logoutButton addTarget:self action:@selector(logoutButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _logoutButton;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
