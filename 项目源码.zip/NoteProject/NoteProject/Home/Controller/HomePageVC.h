//
//  HomePageVC.h
//  NoteProject
//
//  Created by MAC on 2023/6/12.
//

#import "BasicMainVC.h"

@interface HomePageVC : BasicMainVC

@end
