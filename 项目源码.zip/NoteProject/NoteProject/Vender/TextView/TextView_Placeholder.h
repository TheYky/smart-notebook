//
//  TextView_Placeholder.h
//  NoteProject
//
//  Created by MAC on 2023/6/12.
//

#import <UIKit/UIKit.h>

@interface TextView_Placeholder : UITextView

@property(nonatomic,copy) NSString *placeholder;

@property(nonatomic,strong) UIColor *placeholderColor;

@end
