//
//  LYLBouncing.h
//  NoteProject
//
//  Created by MAC on 2023/6/12.
//

#import <UIKit/UIKit.h>
#import "LYLConstants.h"

@interface LYLBouncing : UIView

- (id)initSuccessCircleWithFrame:(CGRect)frame AlertType:(AlertType)type Color:(UIColor*)color;

@end
