//
//  LoginView.h
//  NoteProject
//
//  Created by MAC on 2023/6/12.
//

#import <UIKit/UIKit.h>

typedef void(^LoginViewBlock)(NSInteger index);

NS_ASSUME_NONNULL_BEGIN

@interface LoginView : UIView

@property (nonatomic, copy) LoginViewBlock loginBlock;

@end

NS_ASSUME_NONNULL_END
