//
//  RegisterView.m
//  NoteProject
//
//  Created by MAC on 2023/6/12.
//

#import "RegisterView.h"
#import "UserDataBaseManager.h"

@interface RegisterView ()<UITextFieldDelegate>

@property (nonatomic, strong) UIView *contentView;
@property (nonatomic, strong) UIImageView *iconImageView;

@property (nonatomic, strong) UILabel *titleLabel;

@property (nonatomic, strong) UIView * loginPhoneView;
@property (nonatomic, strong) UIImageView * phoneImageView;
@property (nonatomic, strong) UITextField * phoneTextField;

@property (nonatomic, strong) UIView * loginPasswordView;
@property (nonatomic, strong) UIImageView * passwordImageView;
@property (nonatomic, strong) UITextField * passwordTextField;

@property (nonatomic, strong) UIButton * submitButton;
@property (nonatomic, strong) UIButton * registerButton;

@property (nonatomic, strong) NSString * currentPhoneNumber;
@property (nonatomic, strong) NSString * currentPasswordNumber;

@property(nonatomic, strong) UITapGestureRecognizer * tapGesture;

@end

@implementation RegisterView

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        
        self.backgroundColor = [UIColor colorWithHexString:@"#64BC80"];
        [self setupUI];
        [self addGestureRecognizer:self.tapGesture];
    }
    return self;
}

- (void)setupUI {
    
    [self addSubview:self.contentView];
    [self.contentView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.top.bottom.equalTo(self);
    }];
    
    [self.contentView addSubview:self.iconImageView];
    [self.iconImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(CGSizeMake(KScalHeight(100), KScalHeight(100)));
        make.top.equalTo(self.contentView).offset(KScalHeight(140));
        make.centerX.equalTo(self.contentView);
    }];
    
    [self.contentView addSubview:self.titleLabel];
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(CGSizeMake(Device_Width, KScalHeight(25)));
        make.top.equalTo(self.iconImageView.mas_bottom).offset(KScalHeight(14));
        make.centerX.equalTo(self.contentView);
    }];
    
    //  账号
    [self.contentView addSubview:self.loginPhoneView];
    [self.loginPhoneView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(CGSizeMake(Device_Width-KScalHeight(56), KScalHeight(50)));
        make.top.equalTo(self.titleLabel.mas_bottom).offset(KScalHeight(26));
        make.centerX.equalTo(self.contentView);
    }];
    
    [self.loginPhoneView addSubview:self.phoneImageView];
    [self.phoneImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(CGSizeMake(KScalHeight(20), KScalHeight(20)));
        make.left.equalTo(self.loginPhoneView).offset(KScalHeight(14));
        make.centerY.equalTo(self.loginPhoneView);
    }];
    
    [self.loginPhoneView addSubview:self.phoneTextField];
    [self.phoneTextField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.phoneImageView.mas_right).offset(KScalHeight(14));
        make.right.equalTo(self.loginPhoneView).offset(-KScalHeight(14));
        make.centerY.equalTo(self.loginPhoneView);
    }];
    
    // 密码
    [self.contentView addSubview:self.loginPasswordView];
    [self.loginPasswordView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(CGSizeMake(Device_Width-KScalHeight(56), KScalHeight(50)));
        make.top.equalTo(self.loginPhoneView.mas_bottom).offset(KScalHeight(22));
        make.centerX.equalTo(self.contentView);
    }];
    
    [self.loginPasswordView addSubview:self.passwordImageView];
    [self.passwordImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(CGSizeMake(KScalHeight(20), KScalHeight(20)));
        make.left.equalTo(self.loginPasswordView).offset(KScalHeight(14));
        make.centerY.equalTo(self.loginPasswordView);
    }];
    
    [self.loginPasswordView addSubview:self.passwordTextField];
    [self.passwordTextField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.passwordImageView.mas_right).offset(KScalHeight(14));
        make.right.equalTo(self.loginPasswordView).offset(-KScalHeight(14));
        make.centerY.equalTo(self.loginPasswordView);
    }];
    
    //登录
    [self.contentView addSubview:self.submitButton];
    [self.submitButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(CGSizeMake(Device_Width-KScalHeight(56), KScalHeight(50)));
        make.top.equalTo(self.loginPasswordView.mas_bottom).offset(KScalHeight(22));
        make.centerX.equalTo(self.contentView);
    }];
    
    //去登录
    [self.contentView addSubview:self.registerButton];
    [self.registerButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.contentView).offset(kStatusBarHeight);
        make.left.equalTo(self.contentView).offset(KScalHeight(14));
        make.size.mas_equalTo(CGSizeMake(KScalHeight(44), KScalHeight(44)));
    }];
    
    [self layoutIfNeeded];
    
    self.loginPasswordView.layer.masksToBounds = YES;
    self.loginPasswordView.layer.cornerRadius = KScalHeight(25);
    self.loginPasswordView.layer.borderWidth = 1.0;
    self.loginPasswordView.layer.borderColor = [UIColor whiteColor].CGColor;
    
    self.loginPhoneView.layer.masksToBounds = YES;
    self.loginPhoneView.layer.cornerRadius = KScalHeight(25);
    self.loginPhoneView.layer.borderWidth = 1.0;
    self.loginPhoneView.layer.borderColor = [UIColor whiteColor].CGColor;
    
    self.submitButton.layer.masksToBounds = YES;
    self.submitButton.layer.cornerRadius = KScalHeight(25);
}

- (void)registerUserInDataBase{
    
    NSInteger maxUserId = 0;
    BOOL hasRegister = NO;
    NSArray * allUser = [UserDataBaseManager queryAllUserInDataBase:Database_User ValueField:@"userInfo"];
    for (UserModel * user in allUser) {
        if([user.userID integerValue] > maxUserId) {
            maxUserId = [user.userID integerValue];
        }
        if([user.account isEqualToString: self.currentPhoneNumber]){
            
            [NoteHUD showToastMessage:@"该账号已注册" toView:self];
            hasRegister = YES;
            break;
        }
    }
    if(hasRegister == NO) {
        NSString * newUserId = [NSString stringWithFormat:@"%ld",maxUserId + 1];
        UserModel * user = [[UserModel alloc] init];
        user.userID = newUserId;
        user.userName = [NSString stringWithFormat:@"User%@",[self getRandStringWithLength:10]];
        user.password = self.currentPasswordNumber;
        user.account = self.currentPhoneNumber;
        [UserDataBaseManager updateUser:user forDataBase:Database_User ValueField:@"userInfo"];
        
        [NoteHUD showToastMessage:@"注册成功，返回登录" toView:self];
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{//主线程
            self.phoneTextField.text = @"";
            self.passwordTextField.text = @"";
            if(self.registerBlock){
                self.registerBlock(1);
            }
        });
    }
}

//产生length个长度随机字符串
- (NSString *)getRandStringWithLength:(int)length {
    NSString *sourceStr = @"0123456789abcdefghijklmnopqrstuvwxyz";
    NSMutableString *resultStr = [[NSMutableString alloc] init];
    for (int i = 0; i < length; i++) {
        unsigned index = arc4random() % [sourceStr length];
        NSString *oneStr = [sourceStr substringWithRange:NSMakeRange(index, 1)];
        [resultStr appendString:oneStr];
    }
    return resultStr;
}

-(void)viewGestureAction:(UITapGestureRecognizer *)tap{

    [self.phoneTextField resignFirstResponder];
    [self.passwordTextField resignFirstResponder];
}

#pragma mark --- text field delegate
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    
    if (textField.text.length == 0 && string.length == 0) {
        return YES;
    }
    
    NSString *inputStr = @"";
    NSUInteger strNums = 0;
    if (string.length) {
        NSMutableString *tempStr = textField.text.mutableCopy;
        [tempStr insertString:string atIndex:range.location];
        
        inputStr = tempStr;
        strNums = tempStr.length;
    } else {
        if (textField.text.length - 1 >= 0) {
            strNums = textField.text.length - 1;
    
            NSString *fiStr = [textField.text substringToIndex:range.location];
            NSString *lastStr = @"";
            if (textField.text.length > fiStr.length) {
                 lastStr = [textField.text substringWithRange:NSMakeRange(range.location + 1, textField.text.length - fiStr.length - 1)];
            }
            NSString *tempStr = [NSString stringWithFormat:@"%@%@", fiStr, lastStr];
            inputStr = tempStr;
        }
    }
    
    if(textField == _phoneTextField) {
        
        self.currentPhoneNumber = inputStr;
        if (strNums > 20) {
            strNums = 20;
            self.currentPhoneNumber = [self.currentPhoneNumber substringToIndex:11];
            return NO;
        }
    }
    if(textField == _passwordTextField) {
        
        self.currentPasswordNumber = inputStr;
        if (strNums > 20) {
            strNums = 20;
            self.currentPasswordNumber = [self.currentPasswordNumber substringToIndex:11];
            return NO;
        }
    }

    return YES;
}

- (void)submitButtonAction:(UIButton *)button{
    
    if(self.currentPhoneNumber.length == 0 && self.currentPasswordNumber.length == 0) {
        [NoteHUD showToastMessage:@"请输入要注册的邮箱和密码" toView: self];
        return;
    }
    
    if(self.currentPhoneNumber.length == 0) {
        
        [NoteHUD showToastMessage:@"请输入要注册的邮箱" toView: self];
        return;
    }
    
    if(self.currentPasswordNumber.length == 0) {
        
        [NoteHUD showToastMessage:@"请输入要注册的密码" toView: self];
        return;
    }
    
    [self.phoneTextField resignFirstResponder];
    [self.passwordTextField resignFirstResponder];
    
    [self registerUserInDataBase];
}

- (void)registerButtonAction:(UIButton *)button{
    
    self.phoneTextField.text = @"";
    self.passwordTextField.text = @"";
    if(self.registerBlock){
        self.registerBlock(0);
    }
    
    [self.phoneTextField resignFirstResponder];
    [self.passwordTextField resignFirstResponder];
}

#pragma mark -- Lazy load

- (UIView *)contentView {
    if (!_contentView) {
        _contentView = [[UIView alloc] init];
        _contentView.backgroundColor = [UIColor clearColor];
    }
    return _contentView;
}

- (UIImageView *)iconImageView{
    
    if (!_iconImageView) {
        _iconImageView = [[UIImageView alloc] init];
        _iconImageView.image = [UIImage imageNamed:@"Login_icon2"];
    }
    return _iconImageView;
}

- (UILabel *)titleLabel{
    
    if (!_titleLabel) {
        _titleLabel = [[UILabel alloc] init];
        _titleLabel.font = [UIFont boldSystemFontOfSize:24];
        _titleLabel.textColor = [UIColor whiteColor];
        _titleLabel.numberOfLines = 1;
        _titleLabel.text = @"多功能备忘录";
        _titleLabel.textAlignment = NSTextAlignmentCenter;
        _titleLabel.lineBreakMode = NSLineBreakByTruncatingTail;
        _titleLabel.backgroundColor = [UIColor clearColor];
    }
    return _titleLabel;
}

- (UIView *)loginPhoneView {
    if (!_loginPhoneView) {
        _loginPhoneView = [[UIView alloc] init];
        _loginPhoneView.backgroundColor = [UIColor clearColor];
    }
    return _loginPhoneView;
}

- (UIImageView *)phoneImageView{
    
    if (!_phoneImageView) {
        _phoneImageView = [[UIImageView alloc] init];
        _phoneImageView.image = [UIImage imageNamed:@"Login_phone_icon"];
    }
    return _phoneImageView;
}

- (UITextField *)phoneTextField {
    if (!_phoneTextField) {
        _phoneTextField = [[UITextField alloc] init];
        _phoneTextField.font = [UIFont systemFontOfSize:16.0];
        _phoneTextField.textAlignment = NSTextAlignmentLeft;
        NSAttributedString *attrString = [[NSAttributedString alloc] initWithString:@"请输入常用邮箱" attributes:
        @{NSForegroundColorAttributeName:[UIColor whiteColor],
                     NSFontAttributeName:[UIFont systemFontOfSize:16.0]
             }];
        _phoneTextField.attributedPlaceholder = attrString;
        _phoneTextField.keyboardType = UIKeyboardTypeDefault;
        _phoneTextField.textColor = [UIColor whiteColor];
        _phoneTextField.delegate = self;
    }
    return _phoneTextField;
}

- (UIView *)loginPasswordView {
    if (!_loginPasswordView) {
        _loginPasswordView = [[UIView alloc] init];
        _loginPasswordView.backgroundColor = [UIColor clearColor];
    }
    return _loginPasswordView;
}

- (UIImageView *)passwordImageView{
    
    if (!_passwordImageView) {
        _passwordImageView = [[UIImageView alloc] init];
        _passwordImageView.image = [UIImage imageNamed:@"Login_password_icon"];
    }
    return _passwordImageView;
}

- (UITextField *)passwordTextField {
    if (!_passwordTextField) {
        _passwordTextField = [[UITextField alloc] init];
        _passwordTextField.font = [UIFont systemFontOfSize:16.0];
        _passwordTextField.textAlignment = NSTextAlignmentLeft;
        NSAttributedString *attrString = [[NSAttributedString alloc] initWithString:@"请输入您的密码" attributes:
        @{NSForegroundColorAttributeName:[UIColor whiteColor],
                     NSFontAttributeName:[UIFont systemFontOfSize:16.0]
             }];
        _passwordTextField.attributedPlaceholder = attrString;
        _passwordTextField.keyboardType = UIKeyboardTypeDefault;
        _passwordTextField.secureTextEntry = YES;
        _passwordTextField.textColor = [UIColor whiteColor];
        _passwordTextField.delegate = self;
    }
    return _passwordTextField;
}

- (UIButton *)submitButton{
    
    if(!_submitButton) {
        _submitButton = [[UIButton alloc] init];
        [_submitButton setTitle:@"注册" forState:UIControlStateNormal];
        [_submitButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_submitButton setBackgroundColor:[UIColor whiteColor]];
        [_submitButton setTitleColor:[UIColor colorWithHex:@"#64BC80"] forState:UIControlStateNormal];
        _submitButton.titleLabel.font = [UIFont boldSystemFontOfSize:18];
        [_submitButton addTarget:self action:@selector(submitButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _submitButton;
}

- (UIButton *)registerButton{
    
    if(!_registerButton) {
        _registerButton = [[UIButton alloc] init];
        [_registerButton setImage:[UIImage imageNamed:@"Back"] forState:UIControlStateNormal];
        [_registerButton addTarget:self action:@selector(registerButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _registerButton;
}

- (UITapGestureRecognizer *)tapGesture {
    
    if(!_tapGesture) {
        _tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(viewGestureAction:)];
    }
    return _tapGesture;
}

@end
