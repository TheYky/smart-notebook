//
//  RegisterView.h
//  NoteProject
//
//  Created by MAC on 2023/6/12.
//

#import <UIKit/UIKit.h>

typedef void(^RegisterViewBlock)(NSInteger index);

NS_ASSUME_NONNULL_BEGIN

@interface RegisterView : UIView

@property (nonatomic, copy) RegisterViewBlock registerBlock;

@end

NS_ASSUME_NONNULL_END
