//
//  LoginVC.m
//  NoteProject
//
//  Created by MAC on 2023/6/12.
//

#import "LoginVC.h"
#import "UserModel.h"
#import "LoginView.h"
#import "RegisterView.h"
#import "HomePageVC.h"

@interface LoginVC ()

@property (nonatomic, strong) LoginView * loginView;
@property (nonatomic, strong) RegisterView * registerView;

@end

@implementation LoginVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"登录";
    
    self.view.backgroundColor = [UIColor colorWithHex:@"#64BC80"];
    
    [UserDataBaseManager createDataBase:Database_User ValueField:@"userInfo"];
    
    [self setupUI];
    
    // Do any additional setup after loading the view.
}

- (void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:animated];
    
    [self.navigationController setNavigationBarHidden:YES];
}

- (void)viewWillDisappear:(BOOL)animated {
    
    [super viewWillDisappear:animated];
    
    [self.navigationController setNavigationBarHidden:NO];
}

- (void)setupUI {
    
    [self.view addSubview:self.loginView];
    [self.loginView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.bottom.top.equalTo(self.view);
    }];
    
    [self.view addSubview:self.registerView];
    [self.registerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.bottom.top.equalTo(self.view);
    }];
    
    self.loginView.hidden = NO;
    self.registerView.hidden = YES;
    
    WeakSelf;
    self.loginView.loginBlock = ^(NSInteger index) {
        if(index == 0){
            // 切换注册
            weakSelf.loginView.hidden = YES;
            weakSelf.registerView.hidden = NO;
        }
        if(index == 1){
            // 登录
            HomePageVC * vc = [[HomePageVC alloc] init];
            [weakSelf.navigationController pushViewController:vc animated:NO];
        }
    };
    
    self.registerView.registerBlock = ^(NSInteger index) {
        
        if(index == 0){
            // 切换登录
            weakSelf.loginView.hidden = NO;
            weakSelf.registerView.hidden = YES;
        }
        if(index == 1){
            // 注册成功
            weakSelf.loginView.hidden = NO;
            weakSelf.registerView.hidden = YES;
        }
    };
}

#pragma -- Lazy load

- (LoginView *)loginView{
    
    if(!_loginView){
        _loginView = [[LoginView alloc]init];
    }
    return _loginView;
}

- (RegisterView *)registerView{
    
    if(!_registerView){
        _registerView = [[RegisterView alloc]init];
    }
    return _registerView;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
