//
//  UserModel.m
//  NoteProject
//
//  Created by MAC on 2023/6/12.
//

#import "UserModel.h"

@implementation UserModel


@end
