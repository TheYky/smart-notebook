//
//  UserModel.h
//  NoteProject
//
//  Created by MAC on 2023/6/12.
//

#import <JSONModel/JSONModel.h>

@interface UserModel : JSONModel

//用户ID
@property(nonatomic,copy)NSString *userID;
//用户姓名
@property(nonatomic,copy)NSString *userName;
//邮箱账号
@property(nonatomic,copy)NSString *account;
//用户密码
@property(nonatomic,copy)NSString *password;

@end
