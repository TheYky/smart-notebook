//
//  BaseModel.h
//  NoteProject
//
//  Created by MAC on 2023/6/12.
//

#import <Foundation/Foundation.h>

@interface BaseModel : NSObject

@end
