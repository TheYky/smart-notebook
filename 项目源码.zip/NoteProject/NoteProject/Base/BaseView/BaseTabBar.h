//
//  BaseTabBar.h
//  NoteProject
//
//  Created by MAC on 2023/6/12.
//
/*===============================================================================
 
 自定义UITabBar；
 
 ===============================================================================*/

#import <UIKit/UIKit.h>

@class BaseTabBar;

@protocol BaseTabBarDelegate <NSObject>

@optional

- (void)tabBarMiddle_BTClick:(BaseTabBar *)tabBar;

@end


@interface BaseTabBar : UITabBar

@property (nonatomic, weak) id<BaseTabBarDelegate> myDelegate ;

@end
