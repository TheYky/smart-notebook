//
//  NoteTool.h
//  NoteProject
//
//  Created by MAC on 2023/6/13.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NoteTool : NSObject

+ (CGFloat)getStatusBarHight;

+(BOOL)is_IPhoneX;

@end

NS_ASSUME_NONNULL_END
