//
//  UIButton+Tool.m
//  NoteProject
//
//  Created by MAC on 2023/6/13.
//

#import "UIButton+Tool.h"

@implementation UIButton (Tool)

- (void)setImageTopTextBottom{
    
    [self setTitleEdgeInsets:
           UIEdgeInsetsMake(self.frame.size.height/2,
                           (self.frame.size.width-self.titleLabel.intrinsicContentSize.width)/2-self.imageView.frame.size.width,
                            0,
                           (self.frame.size.width-self.titleLabel.intrinsicContentSize.width)/2)];
    [self setImageEdgeInsets:
               UIEdgeInsetsMake(
                           0,
                           (self.frame.size.width-self.imageView.frame.size.width)/2,
                                self.titleLabel.intrinsicContentSize.height,
                           (self.frame.size.width-self.imageView.frame.size.width)/2)];
}

- (void)setImageTopTextBottomWithMargin:(CGFloat)marginTop{
    
    [self setTitleEdgeInsets:
           UIEdgeInsetsMake(self.frame.size.height/2-marginTop,
                           (self.frame.size.width-self.titleLabel.intrinsicContentSize.width)/2-self.imageView.frame.size.width,
                            0,
                           (self.frame.size.width-self.titleLabel.intrinsicContentSize.width)/2)];
    [self setImageEdgeInsets:
               UIEdgeInsetsMake(
                           0-marginTop,
                           (self.frame.size.width-self.imageView.frame.size.width)/2,
                                self.titleLabel.intrinsicContentSize.height,
                           (self.frame.size.width-self.imageView.frame.size.width)/2)];
}

- (void)setTabbrImageTopTextBottom{
    
    [self setImageEdgeInsets:
               UIEdgeInsetsMake(
                           -10.0,
                           (self.frame.size.width-self.imageView.frame.size.width)/2,
                                self.titleLabel.intrinsicContentSize.height,
                           (self.frame.size.width-self.imageView.frame.size.width)/2)];
    
    [self setTitleEdgeInsets:
           UIEdgeInsetsMake(self.frame.size.height-10,
                           (self.frame.size.width-self.titleLabel.intrinsicContentSize.width)/2-self.imageView.frame.size.width,
                            0,
                           (self.frame.size.width-self.titleLabel.intrinsicContentSize.width)/2)];
}

- (void)setImageRightTextLeft {
    
    [self setSemanticContentAttribute:UISemanticContentAttributeForceRightToLeft];
    //设置图片和文字之间的间隙
    self.imageEdgeInsets = UIEdgeInsetsMake(0, 5, 0, 0);
}

@end
