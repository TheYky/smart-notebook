//
//  NoteTool.m
//  NoteProject
//
//  Created by MAC on 2023/6/13.
//

#import "NoteTool.h"

@implementation NoteTool

+ (CGFloat)getStatusBarHight{
    CGFloat statusBarHeight = 0.0;
    if (@available(iOS 13.0, *)) {
        UIStatusBarManager *statusBarManager = [UIApplication sharedApplication].windows.firstObject.windowScene.statusBarManager;
        statusBarHeight = statusBarManager.statusBarFrame.size.height;
    }
    else {
        statusBarHeight = [UIApplication sharedApplication].statusBarFrame.size.height;
    }
    return statusBarHeight;
}

+(BOOL)is_IPhoneX
{
    if (UIDevice.currentDevice.userInterfaceIdiom != UIUserInterfaceIdiomPhone) {
        return NO;
    }
    UIWindow * mainWindow = [UIApplication sharedApplication].windows.firstObject;
    
    if (mainWindow == nil) {
        return NO;
    }
    
    static BOOL yq_iPhoneX;
    static dispatch_once_t onceToken_iphonex;
    dispatch_once(&onceToken_iphonex, ^{
        /// 先判断设备是否是iPhone/iPod
        if (@available(iOS 11.0, *)) {
            /// 利用safeAreaInsets.bottom > 0.0来判断是否是iPhone X。
            if (mainWindow.safeAreaInsets.bottom > 0.0) {
                yq_iPhoneX = YES;
            }
        }
    });
    return yq_iPhoneX;
}

@end
