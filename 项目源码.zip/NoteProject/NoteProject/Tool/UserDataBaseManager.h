//
//  UserDataBaseManager.h
//  NoteProject
//
//  Created by MAC on 2023/6/13.
//

#import <Foundation/Foundation.h>
#import "UserModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface UserDataBaseManager : NSObject

/** 创建数据库 */
+ (BOOL)createDataBase:(NSString *)dataBase ValueField:(NSString *)ValueField;
/** 更新／添加对象到数据库 */
+ (NSString *)updateUser:(UserModel *)Model forDataBase:(NSString *)dataBase ValueField:(NSString *)ValueField;
/** 根据ID查询对象 */
+ (UserModel *)queryUserOfID:(NSString *)ID InDataBase:(NSString *)dataBase ValueField:(NSString *)ValueField;
/** 查询表内所有对象 */
+ (NSArray *)queryAllUserInDataBase:(NSString *)dataBase ValueField:(NSString *)ValueField;
/** 删除指定对象 */
+ (NSString *)deleteUserOfModel:(UserModel *)Model InDataBase:(NSString *)dataBase;
/** 删除表内所有对象 */
+ (NSString *)deleteAllUserInDataBase:(NSString *)dataBase;

@end

NS_ASSUME_NONNULL_END
