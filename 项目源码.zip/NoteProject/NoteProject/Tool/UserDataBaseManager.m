//
//  UserDataBaseManager.m
//  NoteProject
//
//  Created by MAC on 2023/6/13.
//

#import "UserDataBaseManager.h"

@implementation UserDataBaseManager

+ (BOOL)createDataBase:(NSString *)dataBase ValueField:(NSString *)ValueField
{
    return [LYLDataBaseManager createDataBaseWithName:dataBase andUserInfoField:ValueField];
}

+ (NSString *)updateUser:(UserModel *)Model forDataBase:(NSString *)dataBase ValueField:(NSString *)ValueField
{
    NSString *modelStr = [Model toJSONString];
    return [LYLDataBaseManager updateUserInfoIntoDataBase:dataBase withUserID:Model.userID andUserInfoField:ValueField andUserInfoValue:modelStr];
}

+ (UserModel *)queryUserOfID:(NSString *)ID InDataBase:(NSString *)dataBase  ValueField:(NSString *)ValueField
{
    NSString *modelStr = [LYLDataBaseManager queryUserInfoInDataBase:dataBase WithUserID:ID andUserInfoField:ValueField];
    NSError *error;
    UserModel *model = [[UserModel alloc]initWithString:modelStr error:&error];
    
    return error ? nil : model;
}

+ (NSArray *)queryAllUserInDataBase:(NSString *)dataBase ValueField:(NSString *)ValueField
{
    NSDictionary *dic = [LYLDataBaseManager queryUserInfosInDataBase:dataBase andUserInfoField:ValueField];
    /*
     
     {"result":@"This dataBase not exists!",
     "userInfosArray":@[]
     };
     
     
     {
     @"user_id":user_id,
     userInfoField:uesrInfoValue
     };
     
     */
    NSMutableArray *modelArr = [NSMutableArray array];
    for (NSDictionary *temp_dic in dic[@"userInfosArray"]) {
        
        UserModel *model = [[UserModel alloc]initWithString:temp_dic[ValueField] error:nil];
        [modelArr addObject:model];
    }
    
    return modelArr;
}

+ (NSString *)deleteUserOfModel:(UserModel *)Model InDataBase:(NSString *)dataBase;
{
    return [LYLDataBaseManager deleteUserInfoInDataBase:dataBase WithUserID:Model.userID];
}

+ (NSString *)deleteAllUserInDataBase:(NSString *)dataBase
{
    return [LYLDataBaseManager deleteAllUserInfoTableInDataBase:dataBase];
}


@end
