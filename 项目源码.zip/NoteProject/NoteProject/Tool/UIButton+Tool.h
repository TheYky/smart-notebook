//
//  UIButton+Tool.h
//  NoteProject
//
//  Created by MAC on 2023/6/13.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIButton (Tool)

- (void)setImageTopTextBottom;

- (void)setImageTopTextBottomWithMargin:(CGFloat)marginTop;

- (void)setImageRightTextLeft;

- (void)setTabbrImageTopTextBottom;

@end

NS_ASSUME_NONNULL_END
