//
//  NoteHUD.m
//  NoteProject
//
//  Created by MAC on 2023/6/13.
//

#import "NoteHUD.h"
#import <MBProgressHUD.h>

@implementation NoteHUD

+(void)showToastMessage:(NSString*)msg toView:(UIView*)view
{
    [self hiddenHUD:view animated:NO];
    if (view == nil) {
        view = [[UIApplication sharedApplication] windows].firstObject;
    }
    
    dispatch_async(dispatch_get_main_queue(), ^{
        
        MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:view animated:YES];
        // Configure for text only and offset down
        hud.mode = MBProgressHUDModeText;
        hud.labelText = msg;
        hud.margin = 10.f;
        hud.removeFromSuperViewOnHide = YES;
        hud.userInteractionEnabled = NO;
        [hud hide:YES afterDelay:3.5f];
    });
}

+(void)hiddenHUD:(UIView*)view animated:(BOOL)animated
{
    if (view == nil) {
        view = [[UIApplication sharedApplication] windows].firstObject;
    }
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [MBProgressHUD hideAllHUDsForView:view animated:animated];
    });
}

@end
