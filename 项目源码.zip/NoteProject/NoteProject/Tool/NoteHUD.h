//
//  NoteHUD.h
//  NoteProject
//
//  Created by MAC on 2023/6/13.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NoteHUD : NSObject

+(void)showToastMessage:(NSString*)msg toView:(UIView*)view;

@end

NS_ASSUME_NONNULL_END
