//
//  UIColor+Extension.h
//  NoteProject
//
//  Created by MAC on 2023/6/15.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIColor (Extension)

+ (UIColor *)colorWithHexString:(NSString *)hexStr;
+ (UIColor*) colorWithHex:(NSString *)hexString; //以前工程用的方法，功能同上
+ (UIColor *)colorWithHexString:(NSString *)hexStr alpha:(CGFloat)alphaValue;
+ (UIColor *)randomColor;
+ (NSString *)hexFromUIColor:(UIColor*) color;

@end

NS_ASSUME_NONNULL_END
