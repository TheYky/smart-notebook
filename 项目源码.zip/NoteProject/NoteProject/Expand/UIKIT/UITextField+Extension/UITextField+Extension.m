//
//  UITextField+Extension.m
//  NoteProject
//
//  Created by MAC on 2023/6/12.
//

#import "UITextField+Extension.h"

@implementation UITextField (Extension)

-(void)LeftImageNamed:(NSString *)Named IMG_size:(CGSize)IMG_size
{
    
    UIImageView *rightView = [[UIImageView alloc]init];
    rightView.image = [UIImage imageNamed:Named];
    rightView.size = IMG_size;
    rightView.contentMode = UIViewContentModeCenter;
    self.leftView = rightView;
    self.leftViewMode = UITextFieldViewModeAlways;
    
}

@end
