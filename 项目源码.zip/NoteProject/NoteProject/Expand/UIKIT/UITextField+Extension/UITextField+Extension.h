//
//  UITextField+Extension.h
//  NoteProject
//
//  Created by MAC on 2023/6/12.
//

#import <UIKit/UIKit.h>

@interface UITextField (Extension)

-(void)LeftImageNamed:(NSString *)Named IMG_size:(CGSize)IMG_size;

@end
