//
//  UIImageView+GIF.h
//  NoteProject
//
//  Created by MAC on 2023/6/12.
//

#import <UIKit/UIKit.h>

@interface UIImageView (GIF)
//帧视图合集
@property (nonatomic,strong)NSArray *image_array;

- (void)showGifImageWithData:(NSData *)data;
- (void)showGifImageWithURL:(NSURL *)url;

@end
