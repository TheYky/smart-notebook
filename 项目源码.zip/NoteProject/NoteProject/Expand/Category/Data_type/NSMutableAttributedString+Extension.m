//
//  NSMutableAttributedString+Extension.m
//  NoteProject
//
//  Created by MAC on 2023/6/12.
//

#import "NSMutableAttributedString+Extension.h"

@implementation NSMutableAttributedString (Extension)


-(void)insertImgs:(UIImage *)Img atIndex:(NSInteger )index IMGrect:(CGRect )IMGrect
{
    if (index <= self.length - 1) {
        
        NSTextAttachment *attatchment = [[NSTextAttachment alloc] init];
        attatchment.image = Img;
        attatchment.bounds = IMGrect;
        [self insertAttributedString:[NSAttributedString attributedStringWithAttachment:attatchment] atIndex:index];
    }
}

@end
