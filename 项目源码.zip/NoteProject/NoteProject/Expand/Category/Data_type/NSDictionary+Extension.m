//
//  NSDictionary+Extension.m
//  NoteProject
//
//  Created by MAC on 2023/6/12.
//

#import "NSDictionary+Extension.h"

@implementation NSDictionary (Extension)

- (NSString*)DictionaryConversionStringOfJson

{
    if (!self) {
        return nil;
    }
    
    NSError *parseError;
    
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:self options:NSJSONWritingPrettyPrinted error:&parseError];
    
    if (parseError) {
        return nil;
    }
    
    return [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    
}

@end
