//
//  NSArray+RemoveDuplicate.m
//  NoteProject
//
//  Created by MAC on 2023/6/12.
//
#import "NSArray+RemoveDuplicate.h"

@implementation NSArray (RemoveDuplicate)
- (instancetype)noRepeatArray {
    return [self newArrayWithArray:self.mutableCopy];
}

- (NSMutableArray *)newArrayWithArray:(NSMutableArray *)array {
    
    NSMutableArray *newArray = [NSMutableArray new];
    
    for (unsigned i = 0; i < [array count]; i++) {
        if (![newArray containsObject:array[i]]) {
            [newArray addObject:array[i]];
        }
    }
    return newArray;
}
@end
