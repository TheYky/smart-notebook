//
//  NSObject+Extension.h
//  NoteProject
//
//  Created by MAC on 2023/6/12.
//

#import <Foundation/Foundation.h>

typedef void(^timingChildThreadsBlock)(NSObject *obj,NSTimeInterval TimeIntervalNow);

@interface NSObject (Extension)
//倒计时器停止时间timeout，多久走一次TimeInterval，timingChildThreadsBlock子线程操作
-(void)startTimingWithTimeOut:(NSTimeInterval)timeout TimeInterval:(NSTimeInterval)TimeInterval timingChildThreadsBlock:(timingChildThreadsBlock)timingChildThreadsBlock;
//倒计时停止
-(void)stopCountDown;
//回到主线程
-(void)dispatch_get_main_queue:(void(^)(void))main_queue;
#pragma mark - 获取最新一张图片
+ (void)GetlatestImageForTakeScreenshot:(BOOL)isTakeScreenshot finished:(void (^)(UIImage *image))finished;
#pragma mark - 获取相簿所有图片
+(void)GetAllImagesInPhotoAlbumFinished:(void (^)(NSMutableArray *images))Finished;

#pragma mark - 手机震动
+(void)iPhoneVibration;

/**
 *  获取对象所有属性
 */
- (NSArray *)getAllPropertiesOfObject:(id)object;



@end
