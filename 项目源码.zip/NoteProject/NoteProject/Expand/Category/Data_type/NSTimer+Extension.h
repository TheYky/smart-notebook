//
//  NSTimer+Extension.h
//  NoteProject
//
//  Created by MAC on 2023/6/12.
//

#import <Foundation/Foundation.h>

@interface NSTimer (Extension)

+(void)startTimingWithTimeInterval:(NSTimeInterval)t timerAction:(void(^)(NSTimer *timer,NSTimeInterval interval))timerAction;
-(void)stopTiming;

@end
