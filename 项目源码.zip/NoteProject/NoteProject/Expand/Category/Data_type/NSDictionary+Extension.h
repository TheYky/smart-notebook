//
//  NSDictionary+Extension.h
//  NoteProject
//
//  Created by MAC on 2023/6/12.
//

#import <Foundation/Foundation.h>

@interface NSDictionary (Extension)

/*
   词典转换为字符串
 */
- (NSString*)DictionaryConversionStringOfJson;

@end
