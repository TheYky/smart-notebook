//
//  NSObject+Release.h
//  NoteProject
//
//  Created by MAC on 2023/6/12.
//

#import <Foundation/Foundation.h>

@interface NSObject (Release)
#pragma mark - 监听对象释放时事件
- (void)addDeallocBlock:(void(^)(void))block;


@end
