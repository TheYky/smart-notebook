//
//  PlayerRateSelectView.h
//  NoteProject
//
//  Created by MAC on 2023/6/15.
//

#import <UIKit/UIKit.h>

typedef void(^PlayerRateSelectBlock)(NSString *rate);

NS_ASSUME_NONNULL_BEGIN

@interface PlayerRateSelectView : UIView

@property (nonatomic, strong) PlayerRateSelectBlock selectBlock;

- (void)show;
- (void)hide;

@property (nonatomic, strong) NSString * rate;

@end

NS_ASSUME_NONNULL_END
