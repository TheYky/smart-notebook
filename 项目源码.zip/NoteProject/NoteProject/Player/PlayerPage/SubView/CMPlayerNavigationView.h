//
//  CMPlayerNavigationView.h
//  NoteProject
//
//  Created by MAC on 2023/6/12.


#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@class CMPlayerItem;

@interface CMPlayerNavigationView : UIView

/**
 返回按钮点击回调
 */
@property (nonatomic, copy) void (^backButtonClickBlock)(__weak UIButton *button);
/**
 根据当前播放item绘制导航

 @param playerItem CMPlayerItem
 */
- (void)renderNavigationViewWithPlayerItem:(CMPlayerItem *)playerItem;

@end

NS_ASSUME_NONNULL_END
