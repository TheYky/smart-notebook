//
//  CMPlayerToolView.h
//  NoteProject
//
//  Created by MAC on 2023/6/12.


#import <UIKit/UIKit.h>

typedef void(^CMPlayerToolBlock)(NSInteger index);

NS_ASSUME_NONNULL_BEGIN

@interface CMPlayerToolView : UIView

@property (nonatomic, copy) CMPlayerToolBlock toolBlock;

@property (nonatomic, copy) NSString * rateString;

@end

NS_ASSUME_NONNULL_END
