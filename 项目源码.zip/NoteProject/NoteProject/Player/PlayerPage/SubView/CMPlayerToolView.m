//
//  CMPlayerToolView.m
//  NoteProject
//
//  Created by MAC on 2023/6/12.


#import "CMPlayerToolView.h"

static UIButton *CMPlayerToolBtn(UIImage *normalImg, UIImage *highlightImg, UIImage *selectedImg) {
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn setImage:normalImg forState:UIControlStateNormal];
    [btn setImage:highlightImg forState:UIControlStateHighlighted];
    [btn setImage:selectedImg forState:UIControlStateSelected];
    return btn;
}

@interface CMPlayerToolView ()

@property (nonatomic, strong) UIButton *loveBtn;
@property (nonatomic, strong) UIButton *downloadBtn;
@property (nonatomic, strong) UIButton *effectBtn;
@property (nonatomic, strong) UIButton *commentBtn;
@property (nonatomic, strong) UIButton *moreBtn;

@end

@implementation CMPlayerToolView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self viewTemplete];
        [self configConstraint];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
}

#pragma mark - Render

- (void)viewTemplete {
//    [self addSubview:self.loveBtn];
//    [self addSubview:self.downloadBtn];
//    [self addSubview:self.effectBtn];
//    [self addSubview:self.commentBtn];
    [self addSubview:self.moreBtn];
}

- (void)configConstraint {
//    [self.effectBtn mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.center.mas_equalTo(0);
//    }];
//
//    [self.downloadBtn mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.centerY.mas_equalTo(0);
//        make.centerX.mas_equalTo(-CMRatioPx(60));
//    }];
//
//    [self.loveBtn mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.centerY.mas_equalTo(0);
//        make.centerX.mas_equalTo(-CMRatioPx(120));
//    }];
//
//    [self.commentBtn mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.centerY.mas_equalTo(0);
//        make.centerX.mas_equalTo(CMRatioPx(60));
//    }];
//
    [self.moreBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(0);
        make.centerX.mas_equalTo(0);
    }];
    
}

- (void)moreBtnClicked:(UIButton *)button{
    
    if(self.toolBlock){
        self.toolBlock(2);
    }
}

- (void)setRateString:(NSString *)rateString {
    
    _rateString = rateString;
    [self.moreBtn setTitle:[NSString stringWithFormat:@"播放速度：%@",_rateString] forState:UIControlStateNormal];
}

#pragma mark - Get

- (UIButton *)loveBtn {
    if (!_loveBtn) {
        _loveBtn = CMPlayerToolBtn(UIImage1(@"cm2_play_icn_love"), UIImage1(@"cm2_play_icn_love_prs"), UIImage1(@"cm2_play_icn_loved"));
        _loveBtn.touchUpInsideBlock = ^(UIButton * _Nonnull __weak button) {
            button.selected = !button.selected;
        };
    }
    return _loveBtn;
}

- (UIButton *)downloadBtn {
    if (!_downloadBtn) {
        _downloadBtn = CMPlayerToolBtn(UIImage1(@"cm2_play_icn_dld"), UIImage1(@"cm2_play_icn_dld_prs"), UIImage1(@""));
    }
    return _downloadBtn;
}

- (UIButton *)effectBtn {
    if (!_effectBtn) {
        _effectBtn = CMPlayerToolBtn(UIImage1(@"cm5_topbar_icn_effect"), UIImage1(@"cm5_topbar_icn_effect_press"), UIImage1(@""));
    }
    return _effectBtn;
}

- (UIButton *)commentBtn {
    if (!_commentBtn) {
        _commentBtn = CMPlayerToolBtn(UIImage1(@"cm2_play_icn_cmt_num"), UIImage1(@"cm2_play_icn_cmt_num_prs"), UIImage1(@""));
        // FIXME: 以下代码为mock数据应删除
        UILabel *demoTitle = [[UILabel alloc] init];
        demoTitle.text = @"";
        demoTitle.font = [UIFont systemFontOfSize:8];
        demoTitle.textColor = CM_TEXT_COLOR_WHT;
        [self.commentBtn addSubview:demoTitle];
        [demoTitle mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(5);
            make.centerX.mas_equalTo(12);
        }];
    }
    return _commentBtn;
}

- (UIButton *)moreBtn {
    if (!_moreBtn) {
        _moreBtn = CMPlayerToolBtn(UIImage1(@"cm2_play_icn_more"), UIImage1(@"cm2_play_icn_more_prs"), UIImage1(@""));
        
        [_moreBtn setTitle:@"播放速度：1.0" forState:UIControlStateNormal];
        [_moreBtn setTitleColor:[UIColor colorWithHex:@"#C0C0C0"] forState:UIControlStateNormal];
        _moreBtn.titleLabel.font = [UIFont systemFontOfSize:20];
        [_moreBtn addTarget:self action:@selector(moreBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
        [_moreBtn setImageRightTextLeft];
    }
    return _moreBtn;
}


@end
