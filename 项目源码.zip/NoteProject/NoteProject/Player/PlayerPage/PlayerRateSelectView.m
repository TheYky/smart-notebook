//
//  PlayerRateSelectView.m
//  NoteProject
//
//  Created by MAC on 2023/6/15.
//

#import "PlayerRateSelectView.h"

@interface PlayerRateSelectView()

@property (nonatomic, strong) UIView * contentView;
@property (nonatomic, strong) UILabel * rateLabel;
@property (nonatomic, strong) UIView * rateView;

@property(nonatomic, strong) NSMutableArray * rateArray;
@property(nonatomic, strong) UITapGestureRecognizer * tapGesture;

@end

@implementation PlayerRateSelectView

- (instancetype)initWithFrame:(CGRect)frame{
    
    if (self == [super initWithFrame:frame]) {
        
        [self setUpUI];
        [self addGestureRecognizer:self.tapGesture];
    }
    
    return self;
}

- (void)setUpUI{
    
    [self addSubview:self.contentView];
    [self.contentView addSubview:self.rateLabel];
    [self.rateLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.contentView).offset(KScalHeight(14));
        make.top.equalTo(self.contentView).offset(KScalHeight(14));
    }];
    
    [self.contentView addSubview:self.rateView];
}

- (void)setRate:(NSString *)rate {
    
    _rate = rate;
    
    self.rateLabel.text = [NSString stringWithFormat:@"倍速播放  %@X",_rate];
    
    [self loadRateView];
}

- (void)loadRateView{
    
    [self.rateView.subviews enumerateObjectsUsingBlock:^(__kindof UIView * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        [obj removeFromSuperview];
    }];
    
    self.rateArray = [NSMutableArray arrayWithArray:@[
        @{@"rate":@"0.5"},
        @{@"rate":@"0.6"},
        @{@"rate":@"0.7"},
        @{@"rate":@"0.8"},
        @{@"rate":@"0.9"},
        @{@"rate":@"1.0"},
        @{@"rate":@"1.1"},
        @{@"rate":@"1.2"},
        @{@"rate":@"1.3"},
        @{@"rate":@"1.4"},
        @{@"rate":@"1.5"},
        @{@"rate":@"1.6"},
        @{@"rate":@"1.7"},
        @{@"rate":@"1.8"},
        @{@"rate":@"1.9"},
        @{@"rate":@"2.0"}
    ]];
    
    CGFloat buttonWidth = (Device_Width - KScalHeight(56))/self.rateArray.count;
    
    UIView * lastView = self.rateView;
    for (int a=0; a<self.rateArray.count; a++) {
        
        NSDictionary * dict = self.rateArray[a];
        NSString * rateStr = dict[@"rate"];
        
        UIButton * button = [[UIButton alloc] init];
        if([rateStr isEqualToString:@"0.5"] ||
           [rateStr isEqualToString:@"1.0"] ||
           [rateStr isEqualToString:@"1.5"] ||
           [rateStr isEqualToString:@"2.0"]){
            [button setImage:[UIImage imageNamed:@"Player_rate_first"] forState:UIControlStateNormal];
        }else{
            [button setImage:[UIImage imageNamed:@"Player_rate_second"] forState:UIControlStateNormal];
        }
        
        if([self.rate isEqualToString:rateStr]) {
            [button setImage:[UIImage imageNamed:@"Player_rate_third"] forState:UIControlStateNormal];
        }
        button.tag = 1000+a;
        [button addTarget:self action:@selector(buttonClicked:) forControlEvents:UIControlEventTouchUpInside];
        
        [self.rateView addSubview:button];
        
        [button mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(buttonWidth, KScalHeight(40)));
            make.top.equalTo(self.rateView);
            if(a==0){
                make.left.equalTo(lastView);
            } else {
                make.left.equalTo(lastView.mas_right);
            }
        }];
        lastView = button;
        
        if([rateStr isEqualToString:@"0.5"] ||
           [rateStr isEqualToString:@"1.0"] ||
           [rateStr isEqualToString:@"1.5"] ||
           [rateStr isEqualToString:@"2.0"]){
            
            UILabel *rateLabel = [[UILabel alloc] init];
            rateLabel.font = [UIFont boldSystemFontOfSize:14];
            rateLabel.textColor = [UIColor whiteColor];
            rateLabel.numberOfLines = 1;
            rateLabel.text = [NSString stringWithFormat:@"%@X",rateStr];
            rateLabel.textAlignment = NSTextAlignmentCenter;
            rateLabel.lineBreakMode = NSLineBreakByTruncatingTail;
            rateLabel.backgroundColor = [UIColor clearColor];
            [self.rateView addSubview:rateLabel];
            
            [rateLabel mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.equalTo(button.mas_bottom).offset(KScalHeight(10));
                make.centerX.equalTo(button);
            }];
        }
    };
}

- (void)buttonClicked:(UIButton *)button{
    
    NSInteger index = button.tag - 1000;
    
    NSDictionary * dict = self.rateArray[index];
    
    if(self.selectBlock){
        self.selectBlock(dict[@"rate"]);
    }
}

- (void)show{
    
    self.hidden = NO;
    
    [self.contentView setFrame:CGRectMake(KScalHeight(14), Device_Height, Device_Width-KScalHeight(28), KScalHeight(120))];
    [UIView animateWithDuration:0.3 animations:^{
        [self.contentView setFrame:CGRectMake(KScalHeight(14), Device_Height-kSafeBottomSpaceBar-KScalHeight(115), Device_Width-KScalHeight(28), KScalHeight(120))];
    } completion:^(BOOL finished) {
        
    }];
}

- (void)hide{
    
    [self.contentView setFrame:CGRectMake(KScalHeight(14), Device_Height-kSafeBottomSpaceBar-KScalHeight(115), Device_Width-KScalHeight(28), KScalHeight(120))];
    [UIView animateWithDuration:0.3 animations:^{
        [self.contentView setFrame:CGRectMake(KScalHeight(14), Device_Height, Device_Width-KScalHeight(28), KScalHeight(120))];
    } completion:^(BOOL finished) {
        self.hidden = YES;
    }];
}

-(void)viewGestureAction:(UITapGestureRecognizer *)tap{

    CGPoint point = [tap locationInView:self];
    point = [self.contentView.layer convertPoint:point fromLayer:self.layer];
    if([self.contentView.layer containsPoint:point]) {
        return;
    }else{
        [self hide];
    }
}

#pragma mark -- Lazy load

- (UITapGestureRecognizer *)tapGesture {
    
    if(!_tapGesture) {
        _tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(viewGestureAction:)];
    }
    return _tapGesture;
}

- (UIView *)contentView {
    
    if(!_contentView){
        _contentView = [[UIView alloc] initWithFrame:CGRectMake(KScalHeight(14), Device_Height-kSafeBottomSpaceBar-KScalHeight(115), Device_Width-KScalHeight(28), KScalHeight(120))];
        _contentView.backgroundColor = [UIColor colorWithHex:@"#59544E"];
        _contentView.layer.masksToBounds = YES;
        _contentView.layer.cornerRadius = KScalHeight(20);
    }
    return _contentView;
}

- (UILabel *)rateLabel{
    
    if (!_rateLabel) {
        _rateLabel = [[UILabel alloc] init];
        _rateLabel.font = [UIFont boldSystemFontOfSize:14];
        _rateLabel.textColor = [UIColor whiteColor];
        _rateLabel.numberOfLines = 1;
        _rateLabel.text = @"倍速播放  0.8X";
        _rateLabel.textAlignment = NSTextAlignmentCenter;
        _rateLabel.lineBreakMode = NSLineBreakByTruncatingTail;
        _rateLabel.backgroundColor = [UIColor clearColor];
    }
    return _rateLabel;
}

- (UIView *)rateView {
    
    if(!_rateView){
        _rateView = [[UIView alloc] initWithFrame:CGRectMake(KScalHeight(14), KScalHeight(40), Device_Width-KScalHeight(56), KScalHeight(70))];
        _rateView.backgroundColor = [UIColor clearColor];
    }
    return _rateView;
}

@end
