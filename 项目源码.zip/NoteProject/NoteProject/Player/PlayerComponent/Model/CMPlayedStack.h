//
//  CMPlayedStack.h
//  NoteProject
//
//  Created by MAC on 2023/6/12.


#import <Foundation/Foundation.h>

#define CM_PLAYED_STACK_SIZE 5

NS_ASSUME_NONNULL_BEGIN

@class CMPlayerItem;

@interface CMPlayedStack : NSObject

#pragma mark - Function

/**
 进栈
 */
- (void)push:(CMPlayerItem *)item;
/**
 出栈
 */
- (CMPlayerItem *)pop;

/**
 栈内资源

 @return idx=0为栈底，idx=lastObjectIdx为栈顶
 */
- (NSArray *)stackSource;


@end

NS_ASSUME_NONNULL_END
