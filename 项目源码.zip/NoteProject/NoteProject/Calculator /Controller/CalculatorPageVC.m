//
//  CalculatorPageVC.m
//  NoteProject
//
//  Created by MAC on 2023/6/12.
//

#import "CalculatorPageVC.h"

@interface CalculatorPageVC ()

@property (nonatomic, strong) UIImageView * bgImageView;

@property (nonatomic, strong) UIButton * backButton;

@end

@implementation CalculatorPageVC

- (void)viewDidLoad {
    
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor clearColor];
    
    [self.view addSubview:self.bgImageView];
    [self.bgImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.bottom.equalTo(self.view);
    }];
    
    self.mainview = [[MainView alloc] initWithFrame:self.view.bounds];
    [self.view addSubview: self.mainview];
    self.mainview.delegate = self;
    self.mainmodel = [[MainModel alloc] init];
    
    _MainArray = [[NSMutableArray alloc]init];
    _MainString = [[NSMutableString alloc] init];
    
    [self.view addSubview:self.backButton];
    [self.backButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view).offset(kStatusBarHeight);
        make.left.equalTo(self.view).offset(KScalHeight(14));
        make.size.mas_equalTo(CGSizeMake(KScalHeight(44), KScalHeight(44)));
    }];
}

// 记录小数点状态
int pointFlag = 0;
// 防止连续输入符号
int secondFlag = 0;
// 记录等于号状态
int equalFlag = 0;
// 记录数字后再输入小数点
int numpoint = 0;
//记录左括号数量
int leftbrackets = 0;


- (void)Chubutton:(UIButton *)button {
    //NSLog(@"%ld",(long)button.tag);
    if (button.tag == 17) { //AC
        //[_MainArray removeAllObjects];
        _MainString = nil;
        _MainString = [[NSMutableString alloc] init];
        self.mainview.label.text = @"0";
        pointFlag = 0;
        secondFlag = 0;
        equalFlag = 0;
        leftbrackets = 0;
    } else if (button.tag == 1) { //0
       // [_MainArray addObject:button.titleLabel.text];
        [_MainString appendString:button.titleLabel.text];
        self.mainview.label.text = _MainString;
        secondFlag = 0;
        numpoint = 0;
    } else if ((button.tag <= 7 && button.tag >= 5) || (button.tag <= 11 && button.tag >= 9) || (button.tag <= 15 && button.tag >= 13)) { //9个数字
        //[_MainArray addObject:button.titleLabel.text];
        [_MainString appendString:button.titleLabel.text];
        self.mainview.label.text = _MainString;
        secondFlag = 0;
        numpoint = 0;
    } else if (button.tag == 3) { //小数点
        if (numpoint == 0 && pointFlag == 0) {
            //[_MainArray addObject:button.titleLabel.text];
            [_MainString appendString:button.titleLabel.text];
            self.mainview.label.text = _MainString;
            pointFlag = 1;
        } else {
            
        }
    } else if (button.tag == 20 || button.tag == 8 || button.tag == 12 || button.tag == 16) { //四个运算符
        if (secondFlag == 0) {
            pointFlag = 0;
            secondFlag = 1;
            numpoint = 1;
            //[_MainArray addObject:button.titleLabel.text];
            NSString * string = self.mainview.firstarray[button.tag];
            [_MainString appendString:string];
            self.mainview.label.text = _MainString;
        } else {
            
        }
    } else if (button.tag == 19) {
        
        pointFlag = 0;
        secondFlag = 0;
        equalFlag = 0;
        leftbrackets = 0;
        
        if(self.mainview.label.text.length > 0) {
            
            NSString * string = _MainString;
            _MainString = [NSMutableString stringWithString:[string substringToIndex:string.length-1]];
            self.mainview.label.text = _MainString;
        }
        
    } else if (button.tag == 4) { //等号
        //[_MainArray addObject:button.titleLabel.text];
        //[_MainString appendString:button.titleLabel.text];
        
        self.mainview.label.text = _MainString;
        [_MainString replaceOccurrencesOfString:@")(" withString:@")*(" options:NSLiteralSearch range:NSMakeRange(0, [_MainString length])];
        const char *cstring = [_MainString UTF8String];
        
        NSMutableString *newstring = [NSMutableString stringWithFormat:@"%@", [self.mainmodel transform:cstring]];
        NSLog(@"%@",newstring);
        if ([newstring isEqualToString:@"error"] || [newstring isEqualToString:@"inf"]) {
            newstring = [NSMutableString stringWithFormat:@"error"];
        } else {
            newstring = [NSMutableString stringWithFormat:@"%@", @(newstring.floatValue)];
            
        }
        
        NSLog(@"%@",newstring);
        self.mainview.label.text = newstring;
        _MainString = nil;
        _MainString = [[NSMutableString alloc] init];
        if ([newstring isEqualToString:@"error"] || [newstring isEqualToString:@"inf"]) {
            
        } else {
            [_MainString appendString:newstring];
        }
      
        pointFlag = 0;
        secondFlag = 0;
        equalFlag = 0;
        leftbrackets = 0;
    } else if (button.tag == 18) { //左
       // [_MainArray addObject:button.titleLabel.text];
        leftbrackets++;
        [_MainString appendString:button.titleLabel.text];
        self.mainview.label.text = _MainString;
        secondFlag = 0;
    } else if (button.tag == 19) { //右
        //[_MainArray addObject:button.titleLabel.text];
        if (leftbrackets != 0) {
            [_MainString appendString:button.titleLabel.text];
            self.mainview.label.text = _MainString;
            leftbrackets--;
        } else {
            
        }
    }
}

- (void)backButtonAction:(UIButton *)button{
    
    [self.navigationController popViewControllerAnimated:NO];
}

- (UIButton *)backButton{
    
    if(!_backButton) {
        _backButton = [[UIButton alloc] init];
        [_backButton setImage:[UIImage imageNamed:@"Back"] forState:UIControlStateNormal];
        [_backButton addTarget:self action:@selector(backButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _backButton;
}

- (UIImageView *)bgImageView{
    
    if (!_bgImageView) {
        _bgImageView = [[UIImageView alloc] init];
        _bgImageView.image = [UIImage imageNamed:@"Home_bg"];
    }
    return _bgImageView;
}

- (UIStatusBarStyle)preferredStatusBarStyle {
    return UIStatusBarStyleLightContent;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
