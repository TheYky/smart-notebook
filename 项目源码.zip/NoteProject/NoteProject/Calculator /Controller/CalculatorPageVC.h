//
//  CalculatorPageVC.h
//  NoteProject
//
//  Created by MAC on 2023/6/12.
//

#import "BasicMainVC.h"
#import "CalculatorPageVC.h"
#import "MainModel.h"
#import "MainView.h"

NS_ASSUME_NONNULL_BEGIN

@interface CalculatorPageVC : BasicMainVC <buttondelegate>

@property (nonatomic, strong) MainView *mainview;
@property (nonatomic, strong) MainModel *mainmodel;
@property (nonatomic, strong) NSMutableArray *MainArray;
@property (nonatomic, strong) NSMutableString *MainString;

@end

NS_ASSUME_NONNULL_END
